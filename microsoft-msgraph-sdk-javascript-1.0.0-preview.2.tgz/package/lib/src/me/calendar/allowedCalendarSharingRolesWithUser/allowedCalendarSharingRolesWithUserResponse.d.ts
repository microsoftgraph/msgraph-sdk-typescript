import { CalendarRoleType } from '../../../models/calendarRoleType';
import { AdditionalDataHolder, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
/** Provides operations to call the allowedCalendarSharingRoles method.  */
export declare class AllowedCalendarSharingRolesWithUserResponse implements AdditionalDataHolder, Parsable {
    /** Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.  */
    private _additionalData;
    /** The value property  */
    private _value?;
    /**
     * Gets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @returns a Record<string, unknown>
     */
    get additionalData(): Record<string, unknown>;
    /**
     * Sets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @param value Value to set for the AdditionalData property.
     */
    set additionalData(value: Record<string, unknown>);
    /**
     * Instantiates a new allowedCalendarSharingRolesWithUserResponse and sets the default values.
     */
    constructor();
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the value property value. The value property
     * @returns a calendarRoleType
     */
    get value(): CalendarRoleType[] | undefined;
    /**
     * Sets the value property value. The value property
     * @param value Value to set for the value property.
     */
    set value(value: CalendarRoleType[] | undefined);
}

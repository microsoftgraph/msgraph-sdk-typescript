/** Get entity from agreementAcceptances by key  */
export declare class AgreementAcceptanceItemRequestBuilderGetQueryParameters {
    /** Select properties to be returned  */
    select?: string[] | undefined;
    /**
     * Maps the query parameters names to their encoded names for the URI template parsing.
     * @param originalName The original query parameter name in the class.
     * @returns a string
     */
    getQueryParameter(originalName: string | undefined): string;
}

/** If the roleAssignmentScheduleInstance is activated by a roleEligibilityScheduleRequest, this is the link to the related schedule instance.  */
export declare class ActivatedUsingRequestBuilderGetQueryParameters {
    /** Expand related entities  */
    expand?: string[] | undefined;
    /** Select properties to be returned  */
    select?: string[] | undefined;
    /**
     * Maps the query parameters names to their encoded names for the URI template parsing.
     * @param originalName The original query parameter name in the class.
     * @returns a string
     */
    getQueryParameter(originalName: string | undefined): string;
}

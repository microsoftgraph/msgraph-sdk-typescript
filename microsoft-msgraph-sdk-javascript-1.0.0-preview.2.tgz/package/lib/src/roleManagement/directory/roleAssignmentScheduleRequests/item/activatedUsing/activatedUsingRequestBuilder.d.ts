import { UnifiedRoleEligibilitySchedule } from '../../../../../models/';
import { ActivatedUsingRequestBuilderGetQueryParameters } from './activatedUsingRequestBuilderGetQueryParameters';
import { RequestAdapter, RequestInformation, RequestOption, ResponseHandler } from '@microsoft/kiota-abstractions';
/** Provides operations to manage the activatedUsing property of the microsoft.graph.unifiedRoleAssignmentScheduleRequest entity.  */
export declare class ActivatedUsingRequestBuilder {
    /** Path parameters for the request  */
    private readonly pathParameters;
    /** The request adapter to use to execute the requests.  */
    private readonly requestAdapter;
    /** Url template to use to build the URL for the current request builder  */
    private readonly urlTemplate;
    /**
     * Instantiates a new ActivatedUsingRequestBuilder and sets the default values.
     * @param pathParameters The raw url or the Url template parameters for the request.
     * @param requestAdapter The request adapter to use to execute the requests.
     */
    constructor(pathParameters: Record<string, unknown> | string | undefined, requestAdapter: RequestAdapter);
    /**
     * If the request is from an eligible administrator to activate a role, this parameter will show the related eligible assignment for that activation.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @returns a RequestInformation
     */
    createGetRequestInformation(queryParameters?: ActivatedUsingRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * If the request is from an eligible administrator to activate a role, this parameter will show the related eligible assignment for that activation.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     * @returns a Promise of UnifiedRoleEligibilitySchedule
     */
    get(queryParameters?: ActivatedUsingRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<UnifiedRoleEligibilitySchedule | undefined>;
}

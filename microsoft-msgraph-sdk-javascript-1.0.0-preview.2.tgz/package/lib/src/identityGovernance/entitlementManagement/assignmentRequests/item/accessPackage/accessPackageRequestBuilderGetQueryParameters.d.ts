/** The access package associated with the accessPackageAssignmentRequest. An access package defines the collections of resource roles and the policies for how one or more users can get access to those resources. Read-only. Nullable.  Supports $expand.  */
export declare class AccessPackageRequestBuilderGetQueryParameters {
    /** Expand related entities  */
    expand?: string[] | undefined;
    /** Select properties to be returned  */
    select?: string[] | undefined;
    /**
     * Maps the query parameters names to their encoded names for the URI template parsing.
     * @param originalName The original query parameter name in the class.
     * @returns a string
     */
    getQueryParameter(originalName: string | undefined): string;
}

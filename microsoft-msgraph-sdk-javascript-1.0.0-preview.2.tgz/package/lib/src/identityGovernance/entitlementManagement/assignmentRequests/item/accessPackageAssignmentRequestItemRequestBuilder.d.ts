import { AccessPackageAssignmentRequest } from '../../../../models/';
import { AccessPackageRequestBuilder } from './accessPackage/accessPackageRequestBuilder';
import { AccessPackageAssignmentRequestItemRequestBuilderGetQueryParameters } from './accessPackageAssignmentRequestItemRequestBuilderGetQueryParameters';
import { AssignmentRequestBuilder } from './assignment/assignmentRequestBuilder';
import { CancelRequestBuilder } from './cancel/cancelRequestBuilder';
import { ReprocessRequestBuilder } from './reprocess/reprocessRequestBuilder';
import { RequestorRequestBuilder } from './requestor/requestorRequestBuilder';
import { RequestAdapter, RequestInformation, RequestOption, ResponseHandler } from '@microsoft/kiota-abstractions';
/** Provides operations to manage the assignmentRequests property of the microsoft.graph.entitlementManagement entity.  */
export declare class AccessPackageAssignmentRequestItemRequestBuilder {
    /** The accessPackage property  */
    get accessPackage(): AccessPackageRequestBuilder;
    /** The assignment property  */
    get assignment(): AssignmentRequestBuilder;
    /** The cancel property  */
    get cancel(): CancelRequestBuilder;
    /** Path parameters for the request  */
    private readonly pathParameters;
    /** The reprocess property  */
    get reprocess(): ReprocessRequestBuilder;
    /** The request adapter to use to execute the requests.  */
    private readonly requestAdapter;
    /** The requestor property  */
    get requestor(): RequestorRequestBuilder;
    /** Url template to use to build the URL for the current request builder  */
    private readonly urlTemplate;
    /**
     * Instantiates a new AccessPackageAssignmentRequestItemRequestBuilder and sets the default values.
     * @param pathParameters The raw url or the Url template parameters for the request.
     * @param requestAdapter The request adapter to use to execute the requests.
     */
    constructor(pathParameters: Record<string, unknown> | string | undefined, requestAdapter: RequestAdapter);
    /**
     * Delete navigation property assignmentRequests for identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createDeleteRequestInformation(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Represents access package assignment requests created by or on behalf of a user.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @returns a RequestInformation
     */
    createGetRequestInformation(queryParameters?: AccessPackageAssignmentRequestItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Update the navigation property assignmentRequests in identityGovernance
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createPatchRequestInformation(body: AccessPackageAssignmentRequest | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Delete navigation property assignmentRequests for identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    delete(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
    /**
     * Represents access package assignment requests created by or on behalf of a user.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     * @returns a Promise of AccessPackageAssignmentRequest
     */
    get(queryParameters?: AccessPackageAssignmentRequestItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<AccessPackageAssignmentRequest | undefined>;
    /**
     * Update the navigation property assignmentRequests in identityGovernance
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    patch(body: AccessPackageAssignmentRequest | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
}

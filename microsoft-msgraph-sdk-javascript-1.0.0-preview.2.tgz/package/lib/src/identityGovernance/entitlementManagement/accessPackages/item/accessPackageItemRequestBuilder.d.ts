import { AccessPackage } from '../../../../models/';
import { AccessPackageItemRequestBuilderGetQueryParameters } from './accessPackageItemRequestBuilderGetQueryParameters';
import { AssignmentPoliciesRequestBuilder } from './assignmentPolicies/assignmentPoliciesRequestBuilder';
import { AccessPackageAssignmentPolicyItemRequestBuilder } from './assignmentPolicies/item/accessPackageAssignmentPolicyItemRequestBuilder';
import { CatalogRequestBuilder } from './catalog/catalogRequestBuilder';
import { GetApplicablePolicyRequirementsRequestBuilder } from './getApplicablePolicyRequirements/getApplicablePolicyRequirementsRequestBuilder';
import { RequestAdapter, RequestInformation, RequestOption, ResponseHandler } from '@microsoft/kiota-abstractions';
/** Provides operations to manage the accessPackages property of the microsoft.graph.entitlementManagement entity.  */
export declare class AccessPackageItemRequestBuilder {
    /** The assignmentPolicies property  */
    get assignmentPolicies(): AssignmentPoliciesRequestBuilder;
    /** The catalog property  */
    get catalog(): CatalogRequestBuilder;
    /** The getApplicablePolicyRequirements property  */
    get getApplicablePolicyRequirements(): GetApplicablePolicyRequirementsRequestBuilder;
    /** Path parameters for the request  */
    private readonly pathParameters;
    /** The request adapter to use to execute the requests.  */
    private readonly requestAdapter;
    /** Url template to use to build the URL for the current request builder  */
    private readonly urlTemplate;
    /**
     * Gets an item from the github.com/microsoftgraph/msgraph-sdk-typescript/.identityGovernance.entitlementManagement.accessPackages.item.assignmentPolicies.item collection
     * @param id Unique identifier of the item
     * @returns a accessPackageAssignmentPolicyItemRequestBuilder
     */
    assignmentPoliciesById(id: string): AccessPackageAssignmentPolicyItemRequestBuilder;
    /**
     * Instantiates a new AccessPackageItemRequestBuilder and sets the default values.
     * @param pathParameters The raw url or the Url template parameters for the request.
     * @param requestAdapter The request adapter to use to execute the requests.
     */
    constructor(pathParameters: Record<string, unknown> | string | undefined, requestAdapter: RequestAdapter);
    /**
     * Delete navigation property accessPackages for identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createDeleteRequestInformation(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Represents access package objects.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @returns a RequestInformation
     */
    createGetRequestInformation(queryParameters?: AccessPackageItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Update the navigation property accessPackages in identityGovernance
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createPatchRequestInformation(body: AccessPackage | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Delete navigation property accessPackages for identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    delete(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
    /**
     * Represents access package objects.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     * @returns a Promise of AccessPackage
     */
    get(queryParameters?: AccessPackageItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<AccessPackage | undefined>;
    /**
     * Update the navigation property accessPackages in identityGovernance
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    patch(body: AccessPackage | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
}

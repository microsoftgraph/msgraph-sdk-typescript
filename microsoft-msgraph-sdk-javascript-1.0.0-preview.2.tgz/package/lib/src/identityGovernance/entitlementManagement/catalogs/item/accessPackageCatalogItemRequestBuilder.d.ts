import { AccessPackageCatalog } from '../../../../models/';
import { AccessPackageCatalogItemRequestBuilderGetQueryParameters } from './accessPackageCatalogItemRequestBuilderGetQueryParameters';
import { AccessPackagesRequestBuilder } from './accessPackages/accessPackagesRequestBuilder';
import { AccessPackageItemRequestBuilder } from './accessPackages/item/accessPackageItemRequestBuilder';
import { RequestAdapter, RequestInformation, RequestOption, ResponseHandler } from '@microsoft/kiota-abstractions';
/** Provides operations to manage the catalogs property of the microsoft.graph.entitlementManagement entity.  */
export declare class AccessPackageCatalogItemRequestBuilder {
    /** The accessPackages property  */
    get accessPackages(): AccessPackagesRequestBuilder;
    /** Path parameters for the request  */
    private readonly pathParameters;
    /** The request adapter to use to execute the requests.  */
    private readonly requestAdapter;
    /** Url template to use to build the URL for the current request builder  */
    private readonly urlTemplate;
    /**
     * Gets an item from the github.com/microsoftgraph/msgraph-sdk-typescript/.identityGovernance.entitlementManagement.catalogs.item.accessPackages.item collection
     * @param id Unique identifier of the item
     * @returns a accessPackageItemRequestBuilder
     */
    accessPackagesById(id: string): AccessPackageItemRequestBuilder;
    /**
     * Instantiates a new AccessPackageCatalogItemRequestBuilder and sets the default values.
     * @param pathParameters The raw url or the Url template parameters for the request.
     * @param requestAdapter The request adapter to use to execute the requests.
     */
    constructor(pathParameters: Record<string, unknown> | string | undefined, requestAdapter: RequestAdapter);
    /**
     * Delete navigation property catalogs for identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createDeleteRequestInformation(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Represents a collection of access packages.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @returns a RequestInformation
     */
    createGetRequestInformation(queryParameters?: AccessPackageCatalogItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Update the navigation property catalogs in identityGovernance
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createPatchRequestInformation(body: AccessPackageCatalog | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Delete navigation property catalogs for identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    delete(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
    /**
     * Represents a collection of access packages.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     * @returns a Promise of AccessPackageCatalog
     */
    get(queryParameters?: AccessPackageCatalogItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<AccessPackageCatalog | undefined>;
    /**
     * Update the navigation property catalogs in identityGovernance
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    patch(body: AccessPackageCatalog | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
}

import { AccessPackageAssignment } from '../../../../models/';
import { AccessPackageRequestBuilder } from './accessPackage/accessPackageRequestBuilder';
import { AccessPackageAssignmentItemRequestBuilderGetQueryParameters } from './accessPackageAssignmentItemRequestBuilderGetQueryParameters';
import { AssignmentPolicyRequestBuilder } from './assignmentPolicy/assignmentPolicyRequestBuilder';
import { ReprocessRequestBuilder } from './reprocess/reprocessRequestBuilder';
import { TargetRequestBuilder } from './target/targetRequestBuilder';
import { RequestAdapter, RequestInformation, RequestOption, ResponseHandler } from '@microsoft/kiota-abstractions';
/** Provides operations to manage the assignments property of the microsoft.graph.entitlementManagement entity.  */
export declare class AccessPackageAssignmentItemRequestBuilder {
    /** The accessPackage property  */
    get accessPackage(): AccessPackageRequestBuilder;
    /** The assignmentPolicy property  */
    get assignmentPolicy(): AssignmentPolicyRequestBuilder;
    /** Path parameters for the request  */
    private readonly pathParameters;
    /** The reprocess property  */
    get reprocess(): ReprocessRequestBuilder;
    /** The request adapter to use to execute the requests.  */
    private readonly requestAdapter;
    /** The target property  */
    get target(): TargetRequestBuilder;
    /** Url template to use to build the URL for the current request builder  */
    private readonly urlTemplate;
    /**
     * Instantiates a new AccessPackageAssignmentItemRequestBuilder and sets the default values.
     * @param pathParameters The raw url or the Url template parameters for the request.
     * @param requestAdapter The request adapter to use to execute the requests.
     */
    constructor(pathParameters: Record<string, unknown> | string | undefined, requestAdapter: RequestAdapter);
    /**
     * Delete navigation property assignments for identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createDeleteRequestInformation(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Represents the grant of an access package to a subject (user or group).
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @returns a RequestInformation
     */
    createGetRequestInformation(queryParameters?: AccessPackageAssignmentItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Update the navigation property assignments in identityGovernance
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createPatchRequestInformation(body: AccessPackageAssignment | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Delete navigation property assignments for identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    delete(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
    /**
     * Represents the grant of an access package to a subject (user or group).
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     * @returns a Promise of AccessPackageAssignment
     */
    get(queryParameters?: AccessPackageAssignmentItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<AccessPackageAssignment | undefined>;
    /**
     * Update the navigation property assignments in identityGovernance
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    patch(body: AccessPackageAssignment | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
}

import { AccessReviewInstance } from '../../../../../../models/';
import { AcceptRecommendationsRequestBuilder } from './acceptRecommendations/acceptRecommendationsRequestBuilder';
import { AccessReviewInstanceItemRequestBuilderGetQueryParameters } from './accessReviewInstanceItemRequestBuilderGetQueryParameters';
import { ApplyDecisionsRequestBuilder } from './applyDecisions/applyDecisionsRequestBuilder';
import { BatchRecordDecisionsRequestBuilder } from './batchRecordDecisions/batchRecordDecisionsRequestBuilder';
import { ContactedReviewersRequestBuilder } from './contactedReviewers/contactedReviewersRequestBuilder';
import { AccessReviewReviewerItemRequestBuilder } from './contactedReviewers/item/accessReviewReviewerItemRequestBuilder';
import { DecisionsRequestBuilder } from './decisions/decisionsRequestBuilder';
import { AccessReviewInstanceDecisionItemItemRequestBuilder } from './decisions/item/accessReviewInstanceDecisionItemItemRequestBuilder';
import { ResetDecisionsRequestBuilder } from './resetDecisions/resetDecisionsRequestBuilder';
import { SendReminderRequestBuilder } from './sendReminder/sendReminderRequestBuilder';
import { StopRequestBuilder } from './stop/stopRequestBuilder';
import { RequestAdapter, RequestInformation, RequestOption, ResponseHandler } from '@microsoft/kiota-abstractions';
/** Provides operations to manage the instances property of the microsoft.graph.accessReviewScheduleDefinition entity.  */
export declare class AccessReviewInstanceItemRequestBuilder {
    /** The acceptRecommendations property  */
    get acceptRecommendations(): AcceptRecommendationsRequestBuilder;
    /** The applyDecisions property  */
    get applyDecisions(): ApplyDecisionsRequestBuilder;
    /** The batchRecordDecisions property  */
    get batchRecordDecisions(): BatchRecordDecisionsRequestBuilder;
    /** The contactedReviewers property  */
    get contactedReviewers(): ContactedReviewersRequestBuilder;
    /** The decisions property  */
    get decisions(): DecisionsRequestBuilder;
    /** Path parameters for the request  */
    private readonly pathParameters;
    /** The request adapter to use to execute the requests.  */
    private readonly requestAdapter;
    /** The resetDecisions property  */
    get resetDecisions(): ResetDecisionsRequestBuilder;
    /** The sendReminder property  */
    get sendReminder(): SendReminderRequestBuilder;
    /** The stop property  */
    get stop(): StopRequestBuilder;
    /** Url template to use to build the URL for the current request builder  */
    private readonly urlTemplate;
    /**
     * Instantiates a new AccessReviewInstanceItemRequestBuilder and sets the default values.
     * @param pathParameters The raw url or the Url template parameters for the request.
     * @param requestAdapter The request adapter to use to execute the requests.
     */
    constructor(pathParameters: Record<string, unknown> | string | undefined, requestAdapter: RequestAdapter);
    /**
     * Gets an item from the github.com/microsoftgraph/msgraph-sdk-typescript/.identityGovernance.accessReviews.definitions.item.instances.item.contactedReviewers.item collection
     * @param id Unique identifier of the item
     * @returns a accessReviewReviewerItemRequestBuilder
     */
    contactedReviewersById(id: string): AccessReviewReviewerItemRequestBuilder;
    /**
     * Delete navigation property instances for identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createDeleteRequestInformation(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * If the accessReviewScheduleDefinition is a recurring access review, instances represent each recurrence. A review that does not recur will have exactly one instance. Instances also represent each unique resource under review in the accessReviewScheduleDefinition. If a review has multiple resources and multiple instances, each resource will have a unique instance for each recurrence.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @returns a RequestInformation
     */
    createGetRequestInformation(queryParameters?: AccessReviewInstanceItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Update the navigation property instances in identityGovernance
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createPatchRequestInformation(body: AccessReviewInstance | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Gets an item from the github.com/microsoftgraph/msgraph-sdk-typescript/.identityGovernance.accessReviews.definitions.item.instances.item.decisions.item collection
     * @param id Unique identifier of the item
     * @returns a accessReviewInstanceDecisionItemItemRequestBuilder
     */
    decisionsById(id: string): AccessReviewInstanceDecisionItemItemRequestBuilder;
    /**
     * Delete navigation property instances for identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    delete(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
    /**
     * If the accessReviewScheduleDefinition is a recurring access review, instances represent each recurrence. A review that does not recur will have exactly one instance. Instances also represent each unique resource under review in the accessReviewScheduleDefinition. If a review has multiple resources and multiple instances, each resource will have a unique instance for each recurrence.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     * @returns a Promise of AccessReviewInstance
     */
    get(queryParameters?: AccessReviewInstanceItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<AccessReviewInstance | undefined>;
    /**
     * Update the navigation property instances in identityGovernance
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    patch(body: AccessReviewInstance | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
}

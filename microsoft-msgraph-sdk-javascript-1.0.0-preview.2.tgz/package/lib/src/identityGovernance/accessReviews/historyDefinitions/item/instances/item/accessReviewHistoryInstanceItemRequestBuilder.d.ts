import { AccessReviewHistoryInstance } from '../../../../../../models/';
import { AccessReviewHistoryInstanceItemRequestBuilderGetQueryParameters } from './accessReviewHistoryInstanceItemRequestBuilderGetQueryParameters';
import { GenerateDownloadUriRequestBuilder } from './generateDownloadUri/generateDownloadUriRequestBuilder';
import { RequestAdapter, RequestInformation, RequestOption, ResponseHandler } from '@microsoft/kiota-abstractions';
/** Provides operations to manage the instances property of the microsoft.graph.accessReviewHistoryDefinition entity.  */
export declare class AccessReviewHistoryInstanceItemRequestBuilder {
    /** The generateDownloadUri property  */
    get generateDownloadUri(): GenerateDownloadUriRequestBuilder;
    /** Path parameters for the request  */
    private readonly pathParameters;
    /** The request adapter to use to execute the requests.  */
    private readonly requestAdapter;
    /** Url template to use to build the URL for the current request builder  */
    private readonly urlTemplate;
    /**
     * Instantiates a new AccessReviewHistoryInstanceItemRequestBuilder and sets the default values.
     * @param pathParameters The raw url or the Url template parameters for the request.
     * @param requestAdapter The request adapter to use to execute the requests.
     */
    constructor(pathParameters: Record<string, unknown> | string | undefined, requestAdapter: RequestAdapter);
    /**
     * Delete navigation property instances for identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createDeleteRequestInformation(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * If the accessReviewHistoryDefinition is a recurring definition, instances represent each recurrence. A definition that does not recur will have exactly one instance.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @returns a RequestInformation
     */
    createGetRequestInformation(queryParameters?: AccessReviewHistoryInstanceItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Update the navigation property instances in identityGovernance
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createPatchRequestInformation(body: AccessReviewHistoryInstance | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Delete navigation property instances for identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    delete(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
    /**
     * If the accessReviewHistoryDefinition is a recurring definition, instances represent each recurrence. A definition that does not recur will have exactly one instance.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     * @returns a Promise of AccessReviewHistoryInstance
     */
    get(queryParameters?: AccessReviewHistoryInstanceItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<AccessReviewHistoryInstance | undefined>;
    /**
     * Update the navigation property instances in identityGovernance
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    patch(body: AccessReviewHistoryInstance | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
}

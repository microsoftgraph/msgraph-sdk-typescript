import { AccessReviewSet } from '../../models/';
import { AccessReviewsRequestBuilderGetQueryParameters } from './accessReviewsRequestBuilderGetQueryParameters';
import { DefinitionsRequestBuilder } from './definitions/definitionsRequestBuilder';
import { AccessReviewScheduleDefinitionItemRequestBuilder } from './definitions/item/accessReviewScheduleDefinitionItemRequestBuilder';
import { HistoryDefinitionsRequestBuilder } from './historyDefinitions/historyDefinitionsRequestBuilder';
import { AccessReviewHistoryDefinitionItemRequestBuilder } from './historyDefinitions/item/accessReviewHistoryDefinitionItemRequestBuilder';
import { RequestAdapter, RequestInformation, RequestOption, ResponseHandler } from '@microsoft/kiota-abstractions';
/** Provides operations to manage the accessReviews property of the microsoft.graph.identityGovernance entity.  */
export declare class AccessReviewsRequestBuilder {
    /** The definitions property  */
    get definitions(): DefinitionsRequestBuilder;
    /** The historyDefinitions property  */
    get historyDefinitions(): HistoryDefinitionsRequestBuilder;
    /** Path parameters for the request  */
    private readonly pathParameters;
    /** The request adapter to use to execute the requests.  */
    private readonly requestAdapter;
    /** Url template to use to build the URL for the current request builder  */
    private readonly urlTemplate;
    /**
     * Instantiates a new AccessReviewsRequestBuilder and sets the default values.
     * @param pathParameters The raw url or the Url template parameters for the request.
     * @param requestAdapter The request adapter to use to execute the requests.
     */
    constructor(pathParameters: Record<string, unknown> | string | undefined, requestAdapter: RequestAdapter);
    /**
     * Delete navigation property accessReviews for identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createDeleteRequestInformation(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Get accessReviews from identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @returns a RequestInformation
     */
    createGetRequestInformation(queryParameters?: AccessReviewsRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Update the navigation property accessReviews in identityGovernance
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createPatchRequestInformation(body: AccessReviewSet | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Gets an item from the github.com/microsoftgraph/msgraph-sdk-typescript/.identityGovernance.accessReviews.definitions.item collection
     * @param id Unique identifier of the item
     * @returns a accessReviewScheduleDefinitionItemRequestBuilder
     */
    definitionsById(id: string): AccessReviewScheduleDefinitionItemRequestBuilder;
    /**
     * Delete navigation property accessReviews for identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    delete(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
    /**
     * Get accessReviews from identityGovernance
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     * @returns a Promise of AccessReviewSet
     */
    get(queryParameters?: AccessReviewsRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<AccessReviewSet | undefined>;
    /**
     * Gets an item from the github.com/microsoftgraph/msgraph-sdk-typescript/.identityGovernance.accessReviews.historyDefinitions.item collection
     * @param id Unique identifier of the item
     * @returns a accessReviewHistoryDefinitionItemRequestBuilder
     */
    historyDefinitionsById(id: string): AccessReviewHistoryDefinitionItemRequestBuilder;
    /**
     * Update the navigation property accessReviews in identityGovernance
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    patch(body: AccessReviewSet | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
}

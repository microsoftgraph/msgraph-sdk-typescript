/** Provides operations to manage the identityGovernance singleton.  */
export declare enum AccessReviewExpirationBehavior {
    KeepAccess = "keepAccess",
    RemoveAccess = "removeAccess",
    AcceptAccessRecommendation = "acceptAccessRecommendation",
    UnknownFutureValue = "unknownFutureValue"
}

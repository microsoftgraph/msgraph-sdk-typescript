import { EntitlementManagementSchedule } from './index';
import { AdditionalDataHolder, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AccessPackageAssignmentRequestRequirements implements AdditionalDataHolder, Parsable {
    /** Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.  */
    private _additionalData;
    /** Indicates whether the requestor is allowed to set a custom schedule.  */
    private _allowCustomAssignmentSchedule?;
    /** Indicates whether a request to add must be approved by an approver.  */
    private _isApprovalRequiredForAdd?;
    /** Indicates whether a request to update must be approved by an approver.  */
    private _isApprovalRequiredForUpdate?;
    /** The description of the policy that the user is trying to request access using.  */
    private _policyDescription?;
    /** The display name of the policy that the user is trying to request access using.  */
    private _policyDisplayName?;
    /** The identifier of the policy that these requirements are associated with. This identifier can be used when creating a new assignment request.  */
    private _policyId?;
    /** Schedule restrictions enforced, if any.  */
    private _schedule?;
    /**
     * Gets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @returns a Record<string, unknown>
     */
    get additionalData(): Record<string, unknown>;
    /**
     * Sets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @param value Value to set for the AdditionalData property.
     */
    set additionalData(value: Record<string, unknown>);
    /**
     * Gets the allowCustomAssignmentSchedule property value. Indicates whether the requestor is allowed to set a custom schedule.
     * @returns a boolean
     */
    get allowCustomAssignmentSchedule(): boolean | undefined;
    /**
     * Sets the allowCustomAssignmentSchedule property value. Indicates whether the requestor is allowed to set a custom schedule.
     * @param value Value to set for the allowCustomAssignmentSchedule property.
     */
    set allowCustomAssignmentSchedule(value: boolean | undefined);
    /**
     * Instantiates a new accessPackageAssignmentRequestRequirements and sets the default values.
     */
    constructor();
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the isApprovalRequiredForAdd property value. Indicates whether a request to add must be approved by an approver.
     * @returns a boolean
     */
    get isApprovalRequiredForAdd(): boolean | undefined;
    /**
     * Sets the isApprovalRequiredForAdd property value. Indicates whether a request to add must be approved by an approver.
     * @param value Value to set for the isApprovalRequiredForAdd property.
     */
    set isApprovalRequiredForAdd(value: boolean | undefined);
    /**
     * Gets the isApprovalRequiredForUpdate property value. Indicates whether a request to update must be approved by an approver.
     * @returns a boolean
     */
    get isApprovalRequiredForUpdate(): boolean | undefined;
    /**
     * Sets the isApprovalRequiredForUpdate property value. Indicates whether a request to update must be approved by an approver.
     * @param value Value to set for the isApprovalRequiredForUpdate property.
     */
    set isApprovalRequiredForUpdate(value: boolean | undefined);
    /**
     * Gets the policyDescription property value. The description of the policy that the user is trying to request access using.
     * @returns a string
     */
    get policyDescription(): string | undefined;
    /**
     * Sets the policyDescription property value. The description of the policy that the user is trying to request access using.
     * @param value Value to set for the policyDescription property.
     */
    set policyDescription(value: string | undefined);
    /**
     * Gets the policyDisplayName property value. The display name of the policy that the user is trying to request access using.
     * @returns a string
     */
    get policyDisplayName(): string | undefined;
    /**
     * Sets the policyDisplayName property value. The display name of the policy that the user is trying to request access using.
     * @param value Value to set for the policyDisplayName property.
     */
    set policyDisplayName(value: string | undefined);
    /**
     * Gets the policyId property value. The identifier of the policy that these requirements are associated with. This identifier can be used when creating a new assignment request.
     * @returns a string
     */
    get policyId(): string | undefined;
    /**
     * Sets the policyId property value. The identifier of the policy that these requirements are associated with. This identifier can be used when creating a new assignment request.
     * @param value Value to set for the policyId property.
     */
    set policyId(value: string | undefined);
    /**
     * Gets the schedule property value. Schedule restrictions enforced, if any.
     * @returns a entitlementManagementSchedule
     */
    get schedule(): EntitlementManagementSchedule | undefined;
    /**
     * Sets the schedule property value. Schedule restrictions enforced, if any.
     * @param value Value to set for the schedule property.
     */
    set schedule(value: EntitlementManagementSchedule | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
}

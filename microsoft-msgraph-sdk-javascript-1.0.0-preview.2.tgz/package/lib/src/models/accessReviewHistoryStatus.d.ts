/** Provides operations to manage the identityGovernance singleton.  */
export declare enum AccessReviewHistoryStatus {
    Done = "done",
    Inprogress = "inprogress",
    Error_escaped = "error_escaped",
    Requested = "requested",
    UnknownFutureValue = "unknownFutureValue"
}

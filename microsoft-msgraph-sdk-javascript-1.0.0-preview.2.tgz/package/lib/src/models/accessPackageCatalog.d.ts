import { AccessPackageCatalogState } from './accessPackageCatalogState';
import { AccessPackageCatalogType } from './accessPackageCatalogType';
import { AccessPackage, Entity } from './index';
import { Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AccessPackageCatalog extends Entity implements Parsable {
    /** The access packages in this catalog. Read-only. Nullable.  */
    private _accessPackages?;
    /** Whether the catalog is created by a user or entitlement management. The possible values are: userManaged, serviceDefault, serviceManaged, unknownFutureValue.  */
    private _catalogType?;
    /** The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z. Read-only.  */
    private _createdDateTime?;
    /** The description of the access package catalog.  */
    private _description?;
    /** The display name of the access package catalog.  */
    private _displayName?;
    /** Whether the access packages in this catalog can be requested by users outside of the tenant.  */
    private _isExternallyVisible?;
    /** The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z. Read-only.  */
    private _modifiedDateTime?;
    /** Has the value published if the access packages are available for management. The possible values are: unpublished, published, unknownFutureValue.  */
    private _state?;
    /**
     * Gets the accessPackages property value. The access packages in this catalog. Read-only. Nullable.
     * @returns a accessPackage
     */
    get accessPackages(): AccessPackage[] | undefined;
    /**
     * Sets the accessPackages property value. The access packages in this catalog. Read-only. Nullable.
     * @param value Value to set for the accessPackages property.
     */
    set accessPackages(value: AccessPackage[] | undefined);
    /**
     * Gets the catalogType property value. Whether the catalog is created by a user or entitlement management. The possible values are: userManaged, serviceDefault, serviceManaged, unknownFutureValue.
     * @returns a accessPackageCatalogType
     */
    get catalogType(): AccessPackageCatalogType | undefined;
    /**
     * Sets the catalogType property value. Whether the catalog is created by a user or entitlement management. The possible values are: userManaged, serviceDefault, serviceManaged, unknownFutureValue.
     * @param value Value to set for the catalogType property.
     */
    set catalogType(value: AccessPackageCatalogType | undefined);
    /**
     * Instantiates a new accessPackageCatalog and sets the default values.
     */
    constructor();
    /**
     * Gets the createdDateTime property value. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z. Read-only.
     * @returns a Date
     */
    get createdDateTime(): Date | undefined;
    /**
     * Sets the createdDateTime property value. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z. Read-only.
     * @param value Value to set for the createdDateTime property.
     */
    set createdDateTime(value: Date | undefined);
    /**
     * Gets the description property value. The description of the access package catalog.
     * @returns a string
     */
    get description(): string | undefined;
    /**
     * Sets the description property value. The description of the access package catalog.
     * @param value Value to set for the description property.
     */
    set description(value: string | undefined);
    /**
     * Gets the displayName property value. The display name of the access package catalog.
     * @returns a string
     */
    get displayName(): string | undefined;
    /**
     * Sets the displayName property value. The display name of the access package catalog.
     * @param value Value to set for the displayName property.
     */
    set displayName(value: string | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the isExternallyVisible property value. Whether the access packages in this catalog can be requested by users outside of the tenant.
     * @returns a boolean
     */
    get isExternallyVisible(): boolean | undefined;
    /**
     * Sets the isExternallyVisible property value. Whether the access packages in this catalog can be requested by users outside of the tenant.
     * @param value Value to set for the isExternallyVisible property.
     */
    set isExternallyVisible(value: boolean | undefined);
    /**
     * Gets the modifiedDateTime property value. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z. Read-only.
     * @returns a Date
     */
    get modifiedDateTime(): Date | undefined;
    /**
     * Sets the modifiedDateTime property value. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z. Read-only.
     * @param value Value to set for the modifiedDateTime property.
     */
    set modifiedDateTime(value: Date | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the state property value. Has the value published if the access packages are available for management. The possible values are: unpublished, published, unknownFutureValue.
     * @returns a accessPackageCatalogState
     */
    get state(): AccessPackageCatalogState | undefined;
    /**
     * Sets the state property value. Has the value published if the access packages are available for management. The possible values are: unpublished, published, unknownFutureValue.
     * @param value Value to set for the state property.
     */
    set state(value: AccessPackageCatalogState | undefined);
}

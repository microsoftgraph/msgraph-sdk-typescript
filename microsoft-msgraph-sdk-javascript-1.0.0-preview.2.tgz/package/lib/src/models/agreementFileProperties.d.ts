import { AgreementFileData, Entity } from './index';
import { Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AgreementFileProperties extends Entity implements Parsable {
    /** The date time representing when the file was created.The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z.  */
    private _createdDateTime?;
    /** Localized display name of the policy file of an agreement. The localized display name is shown to end users who view the agreement.  */
    private _displayName?;
    /** Data that represents the terms of use PDF document. Read-only.  */
    private _fileData?;
    /** Name of the agreement file (for example, TOU.pdf). Read-only.  */
    private _fileName?;
    /** If none of the languages matches the client preference, indicates whether this is the default agreement file . If none of the files are marked as default, the first one is treated as the default. Read-only.  */
    private _isDefault?;
    /** Indicates whether the agreement file is a major version update. Major version updates invalidate the agreement's acceptances on the corresponding language.  */
    private _isMajorVersion?;
    /** The language of the agreement file in the format 'languagecode2-country/regioncode2'. 'languagecode2' is a lowercase two-letter code derived from ISO 639-1, while 'country/regioncode2' is derived from ISO 3166 and usually consists of two uppercase letters, or a BCP-47 language tag. For example, U.S. English is en-US. Read-only.  */
    private _language?;
    /**
     * Instantiates a new agreementFileProperties and sets the default values.
     */
    constructor();
    /**
     * Gets the createdDateTime property value. The date time representing when the file was created.The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z.
     * @returns a Date
     */
    get createdDateTime(): Date | undefined;
    /**
     * Sets the createdDateTime property value. The date time representing when the file was created.The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z.
     * @param value Value to set for the createdDateTime property.
     */
    set createdDateTime(value: Date | undefined);
    /**
     * Gets the displayName property value. Localized display name of the policy file of an agreement. The localized display name is shown to end users who view the agreement.
     * @returns a string
     */
    get displayName(): string | undefined;
    /**
     * Sets the displayName property value. Localized display name of the policy file of an agreement. The localized display name is shown to end users who view the agreement.
     * @param value Value to set for the displayName property.
     */
    set displayName(value: string | undefined);
    /**
     * Gets the fileData property value. Data that represents the terms of use PDF document. Read-only.
     * @returns a agreementFileData
     */
    get fileData(): AgreementFileData | undefined;
    /**
     * Sets the fileData property value. Data that represents the terms of use PDF document. Read-only.
     * @param value Value to set for the fileData property.
     */
    set fileData(value: AgreementFileData | undefined);
    /**
     * Gets the fileName property value. Name of the agreement file (for example, TOU.pdf). Read-only.
     * @returns a string
     */
    get fileName(): string | undefined;
    /**
     * Sets the fileName property value. Name of the agreement file (for example, TOU.pdf). Read-only.
     * @param value Value to set for the fileName property.
     */
    set fileName(value: string | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the isDefault property value. If none of the languages matches the client preference, indicates whether this is the default agreement file . If none of the files are marked as default, the first one is treated as the default. Read-only.
     * @returns a boolean
     */
    get isDefault(): boolean | undefined;
    /**
     * Sets the isDefault property value. If none of the languages matches the client preference, indicates whether this is the default agreement file . If none of the files are marked as default, the first one is treated as the default. Read-only.
     * @param value Value to set for the isDefault property.
     */
    set isDefault(value: boolean | undefined);
    /**
     * Gets the isMajorVersion property value. Indicates whether the agreement file is a major version update. Major version updates invalidate the agreement's acceptances on the corresponding language.
     * @returns a boolean
     */
    get isMajorVersion(): boolean | undefined;
    /**
     * Sets the isMajorVersion property value. Indicates whether the agreement file is a major version update. Major version updates invalidate the agreement's acceptances on the corresponding language.
     * @param value Value to set for the isMajorVersion property.
     */
    set isMajorVersion(value: boolean | undefined);
    /**
     * Gets the language property value. The language of the agreement file in the format 'languagecode2-country/regioncode2'. 'languagecode2' is a lowercase two-letter code derived from ISO 639-1, while 'country/regioncode2' is derived from ISO 3166 and usually consists of two uppercase letters, or a BCP-47 language tag. For example, U.S. English is en-US. Read-only.
     * @returns a string
     */
    get language(): string | undefined;
    /**
     * Sets the language property value. The language of the agreement file in the format 'languagecode2-country/regioncode2'. 'languagecode2' is a lowercase two-letter code derived from ISO 639-1, while 'country/regioncode2' is derived from ISO 3166 and usually consists of two uppercase letters, or a BCP-47 language tag. For example, U.S. English is en-US. Read-only.
     * @param value Value to set for the language property.
     */
    set language(value: string | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
}

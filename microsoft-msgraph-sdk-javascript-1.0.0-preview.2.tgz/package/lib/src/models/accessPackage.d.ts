import { AccessPackageAssignmentPolicy, AccessPackageCatalog, Entity } from './index';
import { Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AccessPackage extends Entity implements Parsable {
    /** Read-only. Nullable.  */
    private _assignmentPolicies?;
    /** Read-only. Nullable.  */
    private _catalog?;
    /** The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z. Read-only.  */
    private _createdDateTime?;
    /** The description of the access package.  */
    private _description?;
    /** The display name of the access package. Supports $filter (eq, contains).  */
    private _displayName?;
    /** Whether the access package is hidden from the requestor.  */
    private _isHidden?;
    /** The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z. Read-only.  */
    private _modifiedDateTime?;
    /**
     * Gets the assignmentPolicies property value. Read-only. Nullable.
     * @returns a accessPackageAssignmentPolicy
     */
    get assignmentPolicies(): AccessPackageAssignmentPolicy[] | undefined;
    /**
     * Sets the assignmentPolicies property value. Read-only. Nullable.
     * @param value Value to set for the assignmentPolicies property.
     */
    set assignmentPolicies(value: AccessPackageAssignmentPolicy[] | undefined);
    /**
     * Gets the catalog property value. Read-only. Nullable.
     * @returns a accessPackageCatalog
     */
    get catalog(): AccessPackageCatalog | undefined;
    /**
     * Sets the catalog property value. Read-only. Nullable.
     * @param value Value to set for the catalog property.
     */
    set catalog(value: AccessPackageCatalog | undefined);
    /**
     * Instantiates a new accessPackage and sets the default values.
     */
    constructor();
    /**
     * Gets the createdDateTime property value. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z. Read-only.
     * @returns a Date
     */
    get createdDateTime(): Date | undefined;
    /**
     * Sets the createdDateTime property value. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z. Read-only.
     * @param value Value to set for the createdDateTime property.
     */
    set createdDateTime(value: Date | undefined);
    /**
     * Gets the description property value. The description of the access package.
     * @returns a string
     */
    get description(): string | undefined;
    /**
     * Sets the description property value. The description of the access package.
     * @param value Value to set for the description property.
     */
    set description(value: string | undefined);
    /**
     * Gets the displayName property value. The display name of the access package. Supports $filter (eq, contains).
     * @returns a string
     */
    get displayName(): string | undefined;
    /**
     * Sets the displayName property value. The display name of the access package. Supports $filter (eq, contains).
     * @param value Value to set for the displayName property.
     */
    set displayName(value: string | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the isHidden property value. Whether the access package is hidden from the requestor.
     * @returns a boolean
     */
    get isHidden(): boolean | undefined;
    /**
     * Sets the isHidden property value. Whether the access package is hidden from the requestor.
     * @param value Value to set for the isHidden property.
     */
    set isHidden(value: boolean | undefined);
    /**
     * Gets the modifiedDateTime property value. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z. Read-only.
     * @returns a Date
     */
    get modifiedDateTime(): Date | undefined;
    /**
     * Sets the modifiedDateTime property value. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z. Read-only.
     * @param value Value to set for the modifiedDateTime property.
     */
    set modifiedDateTime(value: Date | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
}

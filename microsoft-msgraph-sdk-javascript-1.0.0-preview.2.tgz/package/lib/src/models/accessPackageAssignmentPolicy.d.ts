import { AllowedTargetScope } from './allowedTargetScope';
import { AccessPackage, AccessPackageAssignmentApprovalSettings, AccessPackageAssignmentRequestorSettings, AccessPackageAssignmentReviewSettings, AccessPackageCatalog, Entity, ExpirationPattern, SubjectSet } from './index';
import { Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AccessPackageAssignmentPolicy extends Entity implements Parsable {
    /** Access package containing this policy. Read-only.  */
    private _accessPackage?;
    /** Principals that can be assigned the access package through this policy. The possible values are: notSpecified, specificDirectoryUsers, specificConnectedOrganizationUsers, specificDirectoryServicePrincipals, allMemberUsers, allDirectoryUsers, allDirectoryServicePrincipals, allConfiguredConnectedOrganizationUsers, allExternalUsers, unknownFutureValue.  */
    private _allowedTargetScope?;
    /** Catalog of the access package containing this policy. Read-only.  */
    private _catalog?;
    /** The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z.  */
    private _createdDateTime?;
    /** The description of the policy.  */
    private _description?;
    /** The display name of the policy.  */
    private _displayName?;
    /** The expiration date for assignments created in this policy.  */
    private _expiration?;
    /** The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z.  */
    private _modifiedDateTime?;
    /** Specifies the settings for approval of requests for an access package assignment through this policy. For example, if approval is required for new requests.  */
    private _requestApprovalSettings?;
    /** Provides additional settings to select who can create a request for an access package assignment through this policy, and what they can include in their request.  */
    private _requestorSettings?;
    /** Settings for access reviews of assignments through this policy.  */
    private _reviewSettings?;
    /** The principals that can be assigned access from an access package through this policy.  */
    private _specificAllowedTargets?;
    /**
     * Gets the accessPackage property value. Access package containing this policy. Read-only.
     * @returns a accessPackage
     */
    get accessPackage(): AccessPackage | undefined;
    /**
     * Sets the accessPackage property value. Access package containing this policy. Read-only.
     * @param value Value to set for the accessPackage property.
     */
    set accessPackage(value: AccessPackage | undefined);
    /**
     * Gets the allowedTargetScope property value. Principals that can be assigned the access package through this policy. The possible values are: notSpecified, specificDirectoryUsers, specificConnectedOrganizationUsers, specificDirectoryServicePrincipals, allMemberUsers, allDirectoryUsers, allDirectoryServicePrincipals, allConfiguredConnectedOrganizationUsers, allExternalUsers, unknownFutureValue.
     * @returns a allowedTargetScope
     */
    get allowedTargetScope(): AllowedTargetScope | undefined;
    /**
     * Sets the allowedTargetScope property value. Principals that can be assigned the access package through this policy. The possible values are: notSpecified, specificDirectoryUsers, specificConnectedOrganizationUsers, specificDirectoryServicePrincipals, allMemberUsers, allDirectoryUsers, allDirectoryServicePrincipals, allConfiguredConnectedOrganizationUsers, allExternalUsers, unknownFutureValue.
     * @param value Value to set for the allowedTargetScope property.
     */
    set allowedTargetScope(value: AllowedTargetScope | undefined);
    /**
     * Gets the catalog property value. Catalog of the access package containing this policy. Read-only.
     * @returns a accessPackageCatalog
     */
    get catalog(): AccessPackageCatalog | undefined;
    /**
     * Sets the catalog property value. Catalog of the access package containing this policy. Read-only.
     * @param value Value to set for the catalog property.
     */
    set catalog(value: AccessPackageCatalog | undefined);
    /**
     * Instantiates a new accessPackageAssignmentPolicy and sets the default values.
     */
    constructor();
    /**
     * Gets the createdDateTime property value. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z.
     * @returns a Date
     */
    get createdDateTime(): Date | undefined;
    /**
     * Sets the createdDateTime property value. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z.
     * @param value Value to set for the createdDateTime property.
     */
    set createdDateTime(value: Date | undefined);
    /**
     * Gets the description property value. The description of the policy.
     * @returns a string
     */
    get description(): string | undefined;
    /**
     * Sets the description property value. The description of the policy.
     * @param value Value to set for the description property.
     */
    set description(value: string | undefined);
    /**
     * Gets the displayName property value. The display name of the policy.
     * @returns a string
     */
    get displayName(): string | undefined;
    /**
     * Sets the displayName property value. The display name of the policy.
     * @param value Value to set for the displayName property.
     */
    set displayName(value: string | undefined);
    /**
     * Gets the expiration property value. The expiration date for assignments created in this policy.
     * @returns a expirationPattern
     */
    get expiration(): ExpirationPattern | undefined;
    /**
     * Sets the expiration property value. The expiration date for assignments created in this policy.
     * @param value Value to set for the expiration property.
     */
    set expiration(value: ExpirationPattern | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the modifiedDateTime property value. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z.
     * @returns a Date
     */
    get modifiedDateTime(): Date | undefined;
    /**
     * Sets the modifiedDateTime property value. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z.
     * @param value Value to set for the modifiedDateTime property.
     */
    set modifiedDateTime(value: Date | undefined);
    /**
     * Gets the requestApprovalSettings property value. Specifies the settings for approval of requests for an access package assignment through this policy. For example, if approval is required for new requests.
     * @returns a accessPackageAssignmentApprovalSettings
     */
    get requestApprovalSettings(): AccessPackageAssignmentApprovalSettings | undefined;
    /**
     * Sets the requestApprovalSettings property value. Specifies the settings for approval of requests for an access package assignment through this policy. For example, if approval is required for new requests.
     * @param value Value to set for the requestApprovalSettings property.
     */
    set requestApprovalSettings(value: AccessPackageAssignmentApprovalSettings | undefined);
    /**
     * Gets the requestorSettings property value. Provides additional settings to select who can create a request for an access package assignment through this policy, and what they can include in their request.
     * @returns a accessPackageAssignmentRequestorSettings
     */
    get requestorSettings(): AccessPackageAssignmentRequestorSettings | undefined;
    /**
     * Sets the requestorSettings property value. Provides additional settings to select who can create a request for an access package assignment through this policy, and what they can include in their request.
     * @param value Value to set for the requestorSettings property.
     */
    set requestorSettings(value: AccessPackageAssignmentRequestorSettings | undefined);
    /**
     * Gets the reviewSettings property value. Settings for access reviews of assignments through this policy.
     * @returns a accessPackageAssignmentReviewSettings
     */
    get reviewSettings(): AccessPackageAssignmentReviewSettings | undefined;
    /**
     * Sets the reviewSettings property value. Settings for access reviews of assignments through this policy.
     * @param value Value to set for the reviewSettings property.
     */
    set reviewSettings(value: AccessPackageAssignmentReviewSettings | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the specificAllowedTargets property value. The principals that can be assigned access from an access package through this policy.
     * @returns a subjectSet
     */
    get specificAllowedTargets(): SubjectSet[] | undefined;
    /**
     * Sets the specificAllowedTargets property value. The principals that can be assigned access from an access package through this policy.
     * @param value Value to set for the specificAllowedTargets property.
     */
    set specificAllowedTargets(value: SubjectSet[] | undefined);
}

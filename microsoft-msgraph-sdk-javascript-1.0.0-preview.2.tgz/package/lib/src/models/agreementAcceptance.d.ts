import { AgreementAcceptanceState } from './agreementAcceptanceState';
import { Entity } from './index';
import { Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AgreementAcceptance extends Entity implements Parsable {
    /** The identifier of the agreement file accepted by the user.  */
    private _agreementFileId?;
    /** The identifier of the agreement.  */
    private _agreementId?;
    /** The display name of the device used for accepting the agreement.  */
    private _deviceDisplayName?;
    /** The unique identifier of the device used for accepting the agreement.  */
    private _deviceId?;
    /** The operating system used to accept the agreement.  */
    private _deviceOSType?;
    /** The operating system version of the device used to accept the agreement.  */
    private _deviceOSVersion?;
    /** The expiration date time of the acceptance. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z.  */
    private _expirationDateTime?;
    /** The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z.  */
    private _recordedDateTime?;
    /** The state of the agreement acceptance. Possible values are: accepted, declined. Supports $filter (eq).  */
    private _state?;
    /** Display name of the user when the acceptance was recorded.  */
    private _userDisplayName?;
    /** Email of the user when the acceptance was recorded.  */
    private _userEmail?;
    /** The identifier of the user who accepted the agreement.  */
    private _userId?;
    /** UPN of the user when the acceptance was recorded.  */
    private _userPrincipalName?;
    /**
     * Gets the agreementFileId property value. The identifier of the agreement file accepted by the user.
     * @returns a string
     */
    get agreementFileId(): string | undefined;
    /**
     * Sets the agreementFileId property value. The identifier of the agreement file accepted by the user.
     * @param value Value to set for the agreementFileId property.
     */
    set agreementFileId(value: string | undefined);
    /**
     * Gets the agreementId property value. The identifier of the agreement.
     * @returns a string
     */
    get agreementId(): string | undefined;
    /**
     * Sets the agreementId property value. The identifier of the agreement.
     * @param value Value to set for the agreementId property.
     */
    set agreementId(value: string | undefined);
    /**
     * Instantiates a new agreementAcceptance and sets the default values.
     */
    constructor();
    /**
     * Gets the deviceDisplayName property value. The display name of the device used for accepting the agreement.
     * @returns a string
     */
    get deviceDisplayName(): string | undefined;
    /**
     * Sets the deviceDisplayName property value. The display name of the device used for accepting the agreement.
     * @param value Value to set for the deviceDisplayName property.
     */
    set deviceDisplayName(value: string | undefined);
    /**
     * Gets the deviceId property value. The unique identifier of the device used for accepting the agreement.
     * @returns a string
     */
    get deviceId(): string | undefined;
    /**
     * Sets the deviceId property value. The unique identifier of the device used for accepting the agreement.
     * @param value Value to set for the deviceId property.
     */
    set deviceId(value: string | undefined);
    /**
     * Gets the deviceOSType property value. The operating system used to accept the agreement.
     * @returns a string
     */
    get deviceOSType(): string | undefined;
    /**
     * Sets the deviceOSType property value. The operating system used to accept the agreement.
     * @param value Value to set for the deviceOSType property.
     */
    set deviceOSType(value: string | undefined);
    /**
     * Gets the deviceOSVersion property value. The operating system version of the device used to accept the agreement.
     * @returns a string
     */
    get deviceOSVersion(): string | undefined;
    /**
     * Sets the deviceOSVersion property value. The operating system version of the device used to accept the agreement.
     * @param value Value to set for the deviceOSVersion property.
     */
    set deviceOSVersion(value: string | undefined);
    /**
     * Gets the expirationDateTime property value. The expiration date time of the acceptance. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z.
     * @returns a Date
     */
    get expirationDateTime(): Date | undefined;
    /**
     * Sets the expirationDateTime property value. The expiration date time of the acceptance. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z.
     * @param value Value to set for the expirationDateTime property.
     */
    set expirationDateTime(value: Date | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the recordedDateTime property value. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z.
     * @returns a Date
     */
    get recordedDateTime(): Date | undefined;
    /**
     * Sets the recordedDateTime property value. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z.
     * @param value Value to set for the recordedDateTime property.
     */
    set recordedDateTime(value: Date | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the state property value. The state of the agreement acceptance. Possible values are: accepted, declined. Supports $filter (eq).
     * @returns a agreementAcceptanceState
     */
    get state(): AgreementAcceptanceState | undefined;
    /**
     * Sets the state property value. The state of the agreement acceptance. Possible values are: accepted, declined. Supports $filter (eq).
     * @param value Value to set for the state property.
     */
    set state(value: AgreementAcceptanceState | undefined);
    /**
     * Gets the userDisplayName property value. Display name of the user when the acceptance was recorded.
     * @returns a string
     */
    get userDisplayName(): string | undefined;
    /**
     * Sets the userDisplayName property value. Display name of the user when the acceptance was recorded.
     * @param value Value to set for the userDisplayName property.
     */
    set userDisplayName(value: string | undefined);
    /**
     * Gets the userEmail property value. Email of the user when the acceptance was recorded.
     * @returns a string
     */
    get userEmail(): string | undefined;
    /**
     * Sets the userEmail property value. Email of the user when the acceptance was recorded.
     * @param value Value to set for the userEmail property.
     */
    set userEmail(value: string | undefined);
    /**
     * Gets the userId property value. The identifier of the user who accepted the agreement.
     * @returns a string
     */
    get userId(): string | undefined;
    /**
     * Sets the userId property value. The identifier of the user who accepted the agreement.
     * @param value Value to set for the userId property.
     */
    set userId(value: string | undefined);
    /**
     * Gets the userPrincipalName property value. UPN of the user when the acceptance was recorded.
     * @returns a string
     */
    get userPrincipalName(): string | undefined;
    /**
     * Sets the userPrincipalName property value. UPN of the user when the acceptance was recorded.
     * @param value Value to set for the userPrincipalName property.
     */
    set userPrincipalName(value: string | undefined);
}

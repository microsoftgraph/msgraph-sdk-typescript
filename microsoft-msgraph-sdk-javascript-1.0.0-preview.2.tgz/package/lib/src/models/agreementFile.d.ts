import { AgreementFileLocalization, AgreementFileProperties } from './index';
import { Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AgreementFile extends AgreementFileProperties implements Parsable {
    /** The localized version of the terms of use agreement files attached to the agreement.  */
    private _localizations?;
    /**
     * Instantiates a new agreementFile and sets the default values.
     */
    constructor();
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the localizations property value. The localized version of the terms of use agreement files attached to the agreement.
     * @returns a agreementFileLocalization
     */
    get localizations(): AgreementFileLocalization[] | undefined;
    /**
     * Sets the localizations property value. The localized version of the terms of use agreement files attached to the agreement.
     * @param value Value to set for the localizations property.
     */
    set localizations(value: AgreementFileLocalization[] | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
}

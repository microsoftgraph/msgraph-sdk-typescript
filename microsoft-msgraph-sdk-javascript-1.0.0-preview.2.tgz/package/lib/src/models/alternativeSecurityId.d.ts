import { AdditionalDataHolder, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AlternativeSecurityId implements AdditionalDataHolder, Parsable {
    /** Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.  */
    private _additionalData;
    /** For internal use only  */
    private _identityProvider?;
    /** For internal use only  */
    private _key?;
    /** For internal use only  */
    private _type?;
    /**
     * Gets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @returns a Record<string, unknown>
     */
    get additionalData(): Record<string, unknown>;
    /**
     * Sets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @param value Value to set for the AdditionalData property.
     */
    set additionalData(value: Record<string, unknown>);
    /**
     * Instantiates a new alternativeSecurityId and sets the default values.
     */
    constructor();
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the identityProvider property value. For internal use only
     * @returns a string
     */
    get identityProvider(): string | undefined;
    /**
     * Sets the identityProvider property value. For internal use only
     * @param value Value to set for the identityProvider property.
     */
    set identityProvider(value: string | undefined);
    /**
     * Gets the key property value. For internal use only
     * @returns a binary
     */
    get key(): string | undefined;
    /**
     * Sets the key property value. For internal use only
     * @param value Value to set for the key property.
     */
    set key(value: string | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the type property value. For internal use only
     * @returns a integer
     */
    get type(): number | undefined;
    /**
     * Sets the type property value. For internal use only
     * @param value Value to set for the type property.
     */
    set type(value: number | undefined);
}

import { PublicError } from './index';
import { AdditionalDataHolder, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class ActionResultPart implements AdditionalDataHolder, Parsable {
    /** Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.  */
    private _additionalData;
    /** The error that occurred, if any, during the course of the bulk operation.  */
    private _error_escaped?;
    /**
     * Gets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @returns a Record<string, unknown>
     */
    get additionalData(): Record<string, unknown>;
    /**
     * Sets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @param value Value to set for the AdditionalData property.
     */
    set additionalData(value: Record<string, unknown>);
    /**
     * Instantiates a new actionResultPart and sets the default values.
     */
    constructor();
    /**
     * Gets the error property value. The error that occurred, if any, during the course of the bulk operation.
     * @returns a publicError
     */
    get error_escaped(): PublicError | undefined;
    /**
     * Sets the error property value. The error that occurred, if any, during the course of the bulk operation.
     * @param value Value to set for the error_escaped property.
     */
    set error_escaped(value: PublicError | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
}

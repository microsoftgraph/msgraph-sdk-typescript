/** Provides operations to call the findMeetingTimes method.  */
export declare enum ActivityDomain {
    Unknown = "unknown",
    Work = "work",
    Personal = "personal",
    Unrestricted = "unrestricted"
}

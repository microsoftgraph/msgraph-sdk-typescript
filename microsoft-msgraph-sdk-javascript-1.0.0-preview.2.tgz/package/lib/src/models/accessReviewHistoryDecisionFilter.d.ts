/** Provides operations to manage the identityGovernance singleton.  */
export declare enum AccessReviewHistoryDecisionFilter {
    Approve = "approve",
    Deny = "deny",
    NotReviewed = "notReviewed",
    DontKnow = "dontKnow",
    NotNotified = "notNotified",
    UnknownFutureValue = "unknownFutureValue"
}

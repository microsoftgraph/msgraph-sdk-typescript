/** Provides operations to manage the identityGovernance singleton.  */
export declare enum AccessPackageCatalogType {
    UserManaged = "userManaged",
    ServiceDefault = "serviceDefault",
    ServiceManaged = "serviceManaged",
    UnknownFutureValue = "unknownFutureValue"
}

import { BucketAggregationDefinition } from './index';
import { AdditionalDataHolder, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AggregationOption implements AdditionalDataHolder, Parsable {
    /** Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.  */
    private _additionalData;
    /** The bucketDefinition property  */
    private _bucketDefinition?;
    /** Computes aggregation on the field while the field exists in current entity type. Required.  */
    private _field?;
    /** The number of searchBucket resources to be returned. This is not required when the range is provided manually in the search request. Optional.  */
    private _size?;
    /**
     * Gets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @returns a Record<string, unknown>
     */
    get additionalData(): Record<string, unknown>;
    /**
     * Sets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @param value Value to set for the AdditionalData property.
     */
    set additionalData(value: Record<string, unknown>);
    /**
     * Gets the bucketDefinition property value. The bucketDefinition property
     * @returns a bucketAggregationDefinition
     */
    get bucketDefinition(): BucketAggregationDefinition | undefined;
    /**
     * Sets the bucketDefinition property value. The bucketDefinition property
     * @param value Value to set for the bucketDefinition property.
     */
    set bucketDefinition(value: BucketAggregationDefinition | undefined);
    /**
     * Instantiates a new aggregationOption and sets the default values.
     */
    constructor();
    /**
     * Gets the field property value. Computes aggregation on the field while the field exists in current entity type. Required.
     * @returns a string
     */
    get field(): string | undefined;
    /**
     * Sets the field property value. Computes aggregation on the field while the field exists in current entity type. Required.
     * @param value Value to set for the field property.
     */
    set field(value: string | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the size property value. The number of searchBucket resources to be returned. This is not required when the range is provided manually in the search request. Optional.
     * @returns a integer
     */
    get size(): number | undefined;
    /**
     * Sets the size property value. The number of searchBucket resources to be returned. This is not required when the range is provided manually in the search request. Optional.
     * @param value Value to set for the size property.
     */
    set size(value: number | undefined);
}

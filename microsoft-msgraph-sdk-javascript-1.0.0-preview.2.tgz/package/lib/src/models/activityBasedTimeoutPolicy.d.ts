import { StsPolicy } from './index';
import { Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class ActivityBasedTimeoutPolicy extends StsPolicy implements Parsable {
    /**
     * Instantiates a new activityBasedTimeoutPolicy and sets the default values.
     */
    constructor();
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
}

import { AccessReviewExpirationBehavior } from './accessReviewExpirationBehavior';
import { EntitlementManagementSchedule, SubjectSet } from './index';
import { AdditionalDataHolder, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AccessPackageAssignmentReviewSettings implements AdditionalDataHolder, Parsable {
    /** Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.  */
    private _additionalData;
    /** The default decision to apply if the access is not reviewed. The possible values are: keepAccess, removeAccess, acceptAccessRecommendation, unknownFutureValue.  */
    private _expirationBehavior?;
    /** This collection specifies the users who will be the fallback reviewers when the primary reviewers don't respond.  */
    private _fallbackReviewers?;
    /** If true, access reviews are required for assignments through this policy.  */
    private _isEnabled?;
    /** Specifies whether to display recommendations to the reviewer. The default value is true.  */
    private _isRecommendationEnabled?;
    /** Specifies whether the reviewer must provide justification for the approval. The default value is true.  */
    private _isReviewerJustificationRequired?;
    /** Specifies whether the principals can review their own assignments.  */
    private _isSelfReview?;
    /** This collection specifies the users or group of users who will review the access package assignments.  */
    private _primaryReviewers?;
    /** When the first review should start and how often it should recur.  */
    private _schedule?;
    /**
     * Gets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @returns a Record<string, unknown>
     */
    get additionalData(): Record<string, unknown>;
    /**
     * Sets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @param value Value to set for the AdditionalData property.
     */
    set additionalData(value: Record<string, unknown>);
    /**
     * Instantiates a new accessPackageAssignmentReviewSettings and sets the default values.
     */
    constructor();
    /**
     * Gets the expirationBehavior property value. The default decision to apply if the access is not reviewed. The possible values are: keepAccess, removeAccess, acceptAccessRecommendation, unknownFutureValue.
     * @returns a accessReviewExpirationBehavior
     */
    get expirationBehavior(): AccessReviewExpirationBehavior | undefined;
    /**
     * Sets the expirationBehavior property value. The default decision to apply if the access is not reviewed. The possible values are: keepAccess, removeAccess, acceptAccessRecommendation, unknownFutureValue.
     * @param value Value to set for the expirationBehavior property.
     */
    set expirationBehavior(value: AccessReviewExpirationBehavior | undefined);
    /**
     * Gets the fallbackReviewers property value. This collection specifies the users who will be the fallback reviewers when the primary reviewers don't respond.
     * @returns a subjectSet
     */
    get fallbackReviewers(): SubjectSet[] | undefined;
    /**
     * Sets the fallbackReviewers property value. This collection specifies the users who will be the fallback reviewers when the primary reviewers don't respond.
     * @param value Value to set for the fallbackReviewers property.
     */
    set fallbackReviewers(value: SubjectSet[] | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the isEnabled property value. If true, access reviews are required for assignments through this policy.
     * @returns a boolean
     */
    get isEnabled(): boolean | undefined;
    /**
     * Sets the isEnabled property value. If true, access reviews are required for assignments through this policy.
     * @param value Value to set for the isEnabled property.
     */
    set isEnabled(value: boolean | undefined);
    /**
     * Gets the isRecommendationEnabled property value. Specifies whether to display recommendations to the reviewer. The default value is true.
     * @returns a boolean
     */
    get isRecommendationEnabled(): boolean | undefined;
    /**
     * Sets the isRecommendationEnabled property value. Specifies whether to display recommendations to the reviewer. The default value is true.
     * @param value Value to set for the isRecommendationEnabled property.
     */
    set isRecommendationEnabled(value: boolean | undefined);
    /**
     * Gets the isReviewerJustificationRequired property value. Specifies whether the reviewer must provide justification for the approval. The default value is true.
     * @returns a boolean
     */
    get isReviewerJustificationRequired(): boolean | undefined;
    /**
     * Sets the isReviewerJustificationRequired property value. Specifies whether the reviewer must provide justification for the approval. The default value is true.
     * @param value Value to set for the isReviewerJustificationRequired property.
     */
    set isReviewerJustificationRequired(value: boolean | undefined);
    /**
     * Gets the isSelfReview property value. Specifies whether the principals can review their own assignments.
     * @returns a boolean
     */
    get isSelfReview(): boolean | undefined;
    /**
     * Sets the isSelfReview property value. Specifies whether the principals can review their own assignments.
     * @param value Value to set for the isSelfReview property.
     */
    set isSelfReview(value: boolean | undefined);
    /**
     * Gets the primaryReviewers property value. This collection specifies the users or group of users who will review the access package assignments.
     * @returns a subjectSet
     */
    get primaryReviewers(): SubjectSet[] | undefined;
    /**
     * Sets the primaryReviewers property value. This collection specifies the users or group of users who will review the access package assignments.
     * @param value Value to set for the primaryReviewers property.
     */
    set primaryReviewers(value: SubjectSet[] | undefined);
    /**
     * Gets the schedule property value. When the first review should start and how often it should recur.
     * @returns a entitlementManagementSchedule
     */
    get schedule(): EntitlementManagementSchedule | undefined;
    /**
     * Sets the schedule property value. When the first review should start and how often it should recur.
     * @param value Value to set for the schedule property.
     */
    set schedule(value: EntitlementManagementSchedule | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
}

import { AccessReviewHistoryStatus } from './accessReviewHistoryStatus';
import { Entity } from './index';
import { Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AccessReviewHistoryInstance extends Entity implements Parsable {
    /** Uri which can be used to retrieve review history data. This URI will be active for 24 hours after being generated. Required.  */
    private _downloadUri?;
    /** Timestamp when this instance and associated data expires and the history is deleted. Required.  */
    private _expirationDateTime?;
    /** Timestamp when all of the available data for this instance was collected. This will be set after this instance's status is set to done. Required.  */
    private _fulfilledDateTime?;
    /** Timestamp, reviews ending on or before this date will be included in the fetched history data.  */
    private _reviewHistoryPeriodEndDateTime?;
    /** Timestamp, reviews starting on or after this date will be included in the fetched history data.  */
    private _reviewHistoryPeriodStartDateTime?;
    /** Timestamp when the instance's history data is scheduled to be generated.  */
    private _runDateTime?;
    /** Represents the status of the review history data collection. The possible values are: done, inProgress, error, requested, unknownFutureValue. Once the status has been marked as done, a link can be generated to retrieve the instance's data by calling generateDownloadUri method.  */
    private _status?;
    /**
     * Instantiates a new accessReviewHistoryInstance and sets the default values.
     */
    constructor();
    /**
     * Gets the downloadUri property value. Uri which can be used to retrieve review history data. This URI will be active for 24 hours after being generated. Required.
     * @returns a string
     */
    get downloadUri(): string | undefined;
    /**
     * Sets the downloadUri property value. Uri which can be used to retrieve review history data. This URI will be active for 24 hours after being generated. Required.
     * @param value Value to set for the downloadUri property.
     */
    set downloadUri(value: string | undefined);
    /**
     * Gets the expirationDateTime property value. Timestamp when this instance and associated data expires and the history is deleted. Required.
     * @returns a Date
     */
    get expirationDateTime(): Date | undefined;
    /**
     * Sets the expirationDateTime property value. Timestamp when this instance and associated data expires and the history is deleted. Required.
     * @param value Value to set for the expirationDateTime property.
     */
    set expirationDateTime(value: Date | undefined);
    /**
     * Gets the fulfilledDateTime property value. Timestamp when all of the available data for this instance was collected. This will be set after this instance's status is set to done. Required.
     * @returns a Date
     */
    get fulfilledDateTime(): Date | undefined;
    /**
     * Sets the fulfilledDateTime property value. Timestamp when all of the available data for this instance was collected. This will be set after this instance's status is set to done. Required.
     * @param value Value to set for the fulfilledDateTime property.
     */
    set fulfilledDateTime(value: Date | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the reviewHistoryPeriodEndDateTime property value. Timestamp, reviews ending on or before this date will be included in the fetched history data.
     * @returns a Date
     */
    get reviewHistoryPeriodEndDateTime(): Date | undefined;
    /**
     * Sets the reviewHistoryPeriodEndDateTime property value. Timestamp, reviews ending on or before this date will be included in the fetched history data.
     * @param value Value to set for the reviewHistoryPeriodEndDateTime property.
     */
    set reviewHistoryPeriodEndDateTime(value: Date | undefined);
    /**
     * Gets the reviewHistoryPeriodStartDateTime property value. Timestamp, reviews starting on or after this date will be included in the fetched history data.
     * @returns a Date
     */
    get reviewHistoryPeriodStartDateTime(): Date | undefined;
    /**
     * Sets the reviewHistoryPeriodStartDateTime property value. Timestamp, reviews starting on or after this date will be included in the fetched history data.
     * @param value Value to set for the reviewHistoryPeriodStartDateTime property.
     */
    set reviewHistoryPeriodStartDateTime(value: Date | undefined);
    /**
     * Gets the runDateTime property value. Timestamp when the instance's history data is scheduled to be generated.
     * @returns a Date
     */
    get runDateTime(): Date | undefined;
    /**
     * Sets the runDateTime property value. Timestamp when the instance's history data is scheduled to be generated.
     * @param value Value to set for the runDateTime property.
     */
    set runDateTime(value: Date | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the status property value. Represents the status of the review history data collection. The possible values are: done, inProgress, error, requested, unknownFutureValue. Once the status has been marked as done, a link can be generated to retrieve the instance's data by calling generateDownloadUri method.
     * @returns a accessReviewHistoryStatus
     */
    get status(): AccessReviewHistoryStatus | undefined;
    /**
     * Sets the status property value. Represents the status of the review history data collection. The possible values are: done, inProgress, error, requested, unknownFutureValue. Once the status has been marked as done, a link can be generated to retrieve the instance's data by calling generateDownloadUri method.
     * @param value Value to set for the status property.
     */
    set status(value: AccessReviewHistoryStatus | undefined);
}

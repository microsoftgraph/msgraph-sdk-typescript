/** Provides operations to manage the security singleton.  */
export declare enum AlertSeverity {
    Unknown = "unknown",
    Informational = "informational",
    Low = "low",
    Medium = "medium",
    High = "high",
    UnknownFutureValue = "unknownFutureValue"
}

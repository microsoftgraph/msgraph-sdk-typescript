/** Provides operations to manage the identityGovernance singleton.  */
export declare enum AccessPackageAssignmentState {
    Delivering = "delivering",
    PartiallyDelivered = "partiallyDelivered",
    Delivered = "delivered",
    Expired = "expired",
    DeliveryFailed = "deliveryFailed",
    UnknownFutureValue = "unknownFutureValue"
}

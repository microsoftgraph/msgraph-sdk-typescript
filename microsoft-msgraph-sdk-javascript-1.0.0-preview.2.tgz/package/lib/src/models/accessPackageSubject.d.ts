import { AccessPackageSubjectType } from './accessPackageSubjectType';
import { ConnectedOrganization, Entity } from './index';
import { Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AccessPackageSubject extends Entity implements Parsable {
    /** The connected organization of the subject. Read-only. Nullable.  */
    private _connectedOrganization?;
    /** The display name of the subject.  */
    private _displayName?;
    /** The email address of the subject.  */
    private _email?;
    /** The object identifier of the subject. null if the subject is not yet a user in the tenant.  */
    private _objectId?;
    /** A string representation of the principal's security identifier, if known, or null if the subject does not have a security identifier.  */
    private _onPremisesSecurityIdentifier?;
    /** The principal name, if known, of the subject.  */
    private _principalName?;
    /** The resource type of the subject. The possible values are: notSpecified, user, servicePrincipal, unknownFutureValue.  */
    private _subjectType?;
    /**
     * Gets the connectedOrganization property value. The connected organization of the subject. Read-only. Nullable.
     * @returns a connectedOrganization
     */
    get connectedOrganization(): ConnectedOrganization | undefined;
    /**
     * Sets the connectedOrganization property value. The connected organization of the subject. Read-only. Nullable.
     * @param value Value to set for the connectedOrganization property.
     */
    set connectedOrganization(value: ConnectedOrganization | undefined);
    /**
     * Instantiates a new accessPackageSubject and sets the default values.
     */
    constructor();
    /**
     * Gets the displayName property value. The display name of the subject.
     * @returns a string
     */
    get displayName(): string | undefined;
    /**
     * Sets the displayName property value. The display name of the subject.
     * @param value Value to set for the displayName property.
     */
    set displayName(value: string | undefined);
    /**
     * Gets the email property value. The email address of the subject.
     * @returns a string
     */
    get email(): string | undefined;
    /**
     * Sets the email property value. The email address of the subject.
     * @param value Value to set for the email property.
     */
    set email(value: string | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the objectId property value. The object identifier of the subject. null if the subject is not yet a user in the tenant.
     * @returns a string
     */
    get objectId(): string | undefined;
    /**
     * Sets the objectId property value. The object identifier of the subject. null if the subject is not yet a user in the tenant.
     * @param value Value to set for the objectId property.
     */
    set objectId(value: string | undefined);
    /**
     * Gets the onPremisesSecurityIdentifier property value. A string representation of the principal's security identifier, if known, or null if the subject does not have a security identifier.
     * @returns a string
     */
    get onPremisesSecurityIdentifier(): string | undefined;
    /**
     * Sets the onPremisesSecurityIdentifier property value. A string representation of the principal's security identifier, if known, or null if the subject does not have a security identifier.
     * @param value Value to set for the onPremisesSecurityIdentifier property.
     */
    set onPremisesSecurityIdentifier(value: string | undefined);
    /**
     * Gets the principalName property value. The principal name, if known, of the subject.
     * @returns a string
     */
    get principalName(): string | undefined;
    /**
     * Sets the principalName property value. The principal name, if known, of the subject.
     * @param value Value to set for the principalName property.
     */
    set principalName(value: string | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the subjectType property value. The resource type of the subject. The possible values are: notSpecified, user, servicePrincipal, unknownFutureValue.
     * @returns a accessPackageSubjectType
     */
    get subjectType(): AccessPackageSubjectType | undefined;
    /**
     * Sets the subjectType property value. The resource type of the subject. The possible values are: notSpecified, user, servicePrincipal, unknownFutureValue.
     * @param value Value to set for the subjectType property.
     */
    set subjectType(value: AccessPackageSubjectType | undefined);
}

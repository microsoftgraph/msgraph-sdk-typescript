/** Provides operations to manage the security singleton.  */
export declare enum AlertStatus {
    Unknown = "unknown",
    NewAlert = "newAlert",
    InProgress = "inProgress",
    Resolved = "resolved",
    Dismissed = "dismissed",
    UnknownFutureValue = "unknownFutureValue"
}

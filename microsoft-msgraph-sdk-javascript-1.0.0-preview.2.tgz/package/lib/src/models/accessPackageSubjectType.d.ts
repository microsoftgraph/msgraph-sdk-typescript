/** Provides operations to manage the identityGovernance singleton.  */
export declare enum AccessPackageSubjectType {
    NotSpecified = "notSpecified",
    User = "user",
    ServicePrincipal = "servicePrincipal",
    UnknownFutureValue = "unknownFutureValue"
}

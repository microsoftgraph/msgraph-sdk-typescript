import { SubjectSet } from './index';
import { AdditionalDataHolder, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AccessPackageAssignmentRequestorSettings implements AdditionalDataHolder, Parsable {
    /** Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.  */
    private _additionalData;
    /** If false, the requestor is not permitted to include a schedule in their request.  */
    private _allowCustomAssignmentSchedule?;
    /** If true, allows on-behalf-of requestors to create a request to add access for another principal.  */
    private _enableOnBehalfRequestorsToAddAccess?;
    /** If true, allows on-behalf-of requestors to create a request to remove access for another principal.  */
    private _enableOnBehalfRequestorsToRemoveAccess?;
    /** If true, allows on-behalf-of requestors to create a request to update access for another principal.  */
    private _enableOnBehalfRequestorsToUpdateAccess?;
    /** If true, allows requestors to create a request to add access for themselves.  */
    private _enableTargetsToSelfAddAccess?;
    /** If true, allows requestors to create a request to remove their access.  */
    private _enableTargetsToSelfRemoveAccess?;
    /** If true, allows requestors to create a request to update their access.  */
    private _enableTargetsToSelfUpdateAccess?;
    /** The principals who can request on-behalf-of others.  */
    private _onBehalfRequestors?;
    /**
     * Gets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @returns a Record<string, unknown>
     */
    get additionalData(): Record<string, unknown>;
    /**
     * Sets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @param value Value to set for the AdditionalData property.
     */
    set additionalData(value: Record<string, unknown>);
    /**
     * Gets the allowCustomAssignmentSchedule property value. If false, the requestor is not permitted to include a schedule in their request.
     * @returns a boolean
     */
    get allowCustomAssignmentSchedule(): boolean | undefined;
    /**
     * Sets the allowCustomAssignmentSchedule property value. If false, the requestor is not permitted to include a schedule in their request.
     * @param value Value to set for the allowCustomAssignmentSchedule property.
     */
    set allowCustomAssignmentSchedule(value: boolean | undefined);
    /**
     * Instantiates a new accessPackageAssignmentRequestorSettings and sets the default values.
     */
    constructor();
    /**
     * Gets the enableOnBehalfRequestorsToAddAccess property value. If true, allows on-behalf-of requestors to create a request to add access for another principal.
     * @returns a boolean
     */
    get enableOnBehalfRequestorsToAddAccess(): boolean | undefined;
    /**
     * Sets the enableOnBehalfRequestorsToAddAccess property value. If true, allows on-behalf-of requestors to create a request to add access for another principal.
     * @param value Value to set for the enableOnBehalfRequestorsToAddAccess property.
     */
    set enableOnBehalfRequestorsToAddAccess(value: boolean | undefined);
    /**
     * Gets the enableOnBehalfRequestorsToRemoveAccess property value. If true, allows on-behalf-of requestors to create a request to remove access for another principal.
     * @returns a boolean
     */
    get enableOnBehalfRequestorsToRemoveAccess(): boolean | undefined;
    /**
     * Sets the enableOnBehalfRequestorsToRemoveAccess property value. If true, allows on-behalf-of requestors to create a request to remove access for another principal.
     * @param value Value to set for the enableOnBehalfRequestorsToRemoveAccess property.
     */
    set enableOnBehalfRequestorsToRemoveAccess(value: boolean | undefined);
    /**
     * Gets the enableOnBehalfRequestorsToUpdateAccess property value. If true, allows on-behalf-of requestors to create a request to update access for another principal.
     * @returns a boolean
     */
    get enableOnBehalfRequestorsToUpdateAccess(): boolean | undefined;
    /**
     * Sets the enableOnBehalfRequestorsToUpdateAccess property value. If true, allows on-behalf-of requestors to create a request to update access for another principal.
     * @param value Value to set for the enableOnBehalfRequestorsToUpdateAccess property.
     */
    set enableOnBehalfRequestorsToUpdateAccess(value: boolean | undefined);
    /**
     * Gets the enableTargetsToSelfAddAccess property value. If true, allows requestors to create a request to add access for themselves.
     * @returns a boolean
     */
    get enableTargetsToSelfAddAccess(): boolean | undefined;
    /**
     * Sets the enableTargetsToSelfAddAccess property value. If true, allows requestors to create a request to add access for themselves.
     * @param value Value to set for the enableTargetsToSelfAddAccess property.
     */
    set enableTargetsToSelfAddAccess(value: boolean | undefined);
    /**
     * Gets the enableTargetsToSelfRemoveAccess property value. If true, allows requestors to create a request to remove their access.
     * @returns a boolean
     */
    get enableTargetsToSelfRemoveAccess(): boolean | undefined;
    /**
     * Sets the enableTargetsToSelfRemoveAccess property value. If true, allows requestors to create a request to remove their access.
     * @param value Value to set for the enableTargetsToSelfRemoveAccess property.
     */
    set enableTargetsToSelfRemoveAccess(value: boolean | undefined);
    /**
     * Gets the enableTargetsToSelfUpdateAccess property value. If true, allows requestors to create a request to update their access.
     * @returns a boolean
     */
    get enableTargetsToSelfUpdateAccess(): boolean | undefined;
    /**
     * Sets the enableTargetsToSelfUpdateAccess property value. If true, allows requestors to create a request to update their access.
     * @param value Value to set for the enableTargetsToSelfUpdateAccess property.
     */
    set enableTargetsToSelfUpdateAccess(value: boolean | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the onBehalfRequestors property value. The principals who can request on-behalf-of others.
     * @returns a subjectSet
     */
    get onBehalfRequestors(): SubjectSet[] | undefined;
    /**
     * Sets the onBehalfRequestors property value. The principals who can request on-behalf-of others.
     * @param value Value to set for the onBehalfRequestors property.
     */
    set onBehalfRequestors(value: SubjectSet[] | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
}

import { AgreementAcceptance, AgreementFile, AgreementFileLocalization, Entity, TermsExpiration } from './index';
import { Duration, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class Agreement extends Entity implements Parsable {
    /** Read-only. Information about acceptances of this agreement.  */
    private _acceptances?;
    /** Display name of the agreement. The display name is used for internal tracking of the agreement but is not shown to end users who view the agreement. Supports $filter (eq).  */
    private _displayName?;
    /** Default PDF linked to this agreement.  */
    private _file?;
    /** PDFs linked to this agreement. This property is in the process of being deprecated. Use the  file property instead. Supports $expand.  */
    private _files?;
    /** Indicates whether end users are required to accept this agreement on every device that they access it from. The end user is required to register their device in Azure AD, if they haven't already done so. Supports $filter (eq).  */
    private _isPerDeviceAcceptanceRequired?;
    /** Indicates whether the user has to expand the agreement before accepting. Supports $filter (eq).  */
    private _isViewingBeforeAcceptanceRequired?;
    /** Expiration schedule and frequency of agreement for all users. Supports $filter (eq).  */
    private _termsExpiration?;
    /** The duration after which the user must re-accept the terms of use. The value is represented in ISO 8601 format for durations. Supports $filter (eq).  */
    private _userReacceptRequiredFrequency?;
    /**
     * Gets the acceptances property value. Read-only. Information about acceptances of this agreement.
     * @returns a agreementAcceptance
     */
    get acceptances(): AgreementAcceptance[] | undefined;
    /**
     * Sets the acceptances property value. Read-only. Information about acceptances of this agreement.
     * @param value Value to set for the acceptances property.
     */
    set acceptances(value: AgreementAcceptance[] | undefined);
    /**
     * Instantiates a new agreement and sets the default values.
     */
    constructor();
    /**
     * Gets the displayName property value. Display name of the agreement. The display name is used for internal tracking of the agreement but is not shown to end users who view the agreement. Supports $filter (eq).
     * @returns a string
     */
    get displayName(): string | undefined;
    /**
     * Sets the displayName property value. Display name of the agreement. The display name is used for internal tracking of the agreement but is not shown to end users who view the agreement. Supports $filter (eq).
     * @param value Value to set for the displayName property.
     */
    set displayName(value: string | undefined);
    /**
     * Gets the file property value. Default PDF linked to this agreement.
     * @returns a agreementFile
     */
    get file(): AgreementFile | undefined;
    /**
     * Sets the file property value. Default PDF linked to this agreement.
     * @param value Value to set for the file property.
     */
    set file(value: AgreementFile | undefined);
    /**
     * Gets the files property value. PDFs linked to this agreement. This property is in the process of being deprecated. Use the  file property instead. Supports $expand.
     * @returns a agreementFileLocalization
     */
    get files(): AgreementFileLocalization[] | undefined;
    /**
     * Sets the files property value. PDFs linked to this agreement. This property is in the process of being deprecated. Use the  file property instead. Supports $expand.
     * @param value Value to set for the files property.
     */
    set files(value: AgreementFileLocalization[] | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the isPerDeviceAcceptanceRequired property value. Indicates whether end users are required to accept this agreement on every device that they access it from. The end user is required to register their device in Azure AD, if they haven't already done so. Supports $filter (eq).
     * @returns a boolean
     */
    get isPerDeviceAcceptanceRequired(): boolean | undefined;
    /**
     * Sets the isPerDeviceAcceptanceRequired property value. Indicates whether end users are required to accept this agreement on every device that they access it from. The end user is required to register their device in Azure AD, if they haven't already done so. Supports $filter (eq).
     * @param value Value to set for the isPerDeviceAcceptanceRequired property.
     */
    set isPerDeviceAcceptanceRequired(value: boolean | undefined);
    /**
     * Gets the isViewingBeforeAcceptanceRequired property value. Indicates whether the user has to expand the agreement before accepting. Supports $filter (eq).
     * @returns a boolean
     */
    get isViewingBeforeAcceptanceRequired(): boolean | undefined;
    /**
     * Sets the isViewingBeforeAcceptanceRequired property value. Indicates whether the user has to expand the agreement before accepting. Supports $filter (eq).
     * @param value Value to set for the isViewingBeforeAcceptanceRequired property.
     */
    set isViewingBeforeAcceptanceRequired(value: boolean | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the termsExpiration property value. Expiration schedule and frequency of agreement for all users. Supports $filter (eq).
     * @returns a termsExpiration
     */
    get termsExpiration(): TermsExpiration | undefined;
    /**
     * Sets the termsExpiration property value. Expiration schedule and frequency of agreement for all users. Supports $filter (eq).
     * @param value Value to set for the termsExpiration property.
     */
    set termsExpiration(value: TermsExpiration | undefined);
    /**
     * Gets the userReacceptRequiredFrequency property value. The duration after which the user must re-accept the terms of use. The value is represented in ISO 8601 format for durations. Supports $filter (eq).
     * @returns a Duration
     */
    get userReacceptRequiredFrequency(): Duration | undefined;
    /**
     * Sets the userReacceptRequiredFrequency property value. The duration after which the user must re-accept the terms of use. The value is represented in ISO 8601 format for durations. Supports $filter (eq).
     * @param value Value to set for the userReacceptRequiredFrequency property.
     */
    set userReacceptRequiredFrequency(value: Duration | undefined);
}

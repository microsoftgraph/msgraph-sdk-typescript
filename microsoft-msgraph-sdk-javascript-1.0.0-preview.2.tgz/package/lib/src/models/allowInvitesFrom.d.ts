/** Provides operations to manage the policyRoot singleton.  */
export declare enum AllowInvitesFrom {
    None = "none",
    AdminsAndGuestInviters = "adminsAndGuestInviters",
    AdminsGuestInvitersAndAllMembers = "adminsGuestInvitersAndAllMembers",
    Everyone = "everyone",
    UnknownFutureValue = "unknownFutureValue"
}

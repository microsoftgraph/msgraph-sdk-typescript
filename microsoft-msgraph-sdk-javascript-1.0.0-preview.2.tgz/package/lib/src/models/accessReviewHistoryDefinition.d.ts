import { AccessReviewHistoryDecisionFilter } from './accessReviewHistoryDecisionFilter';
import { AccessReviewHistoryStatus } from './accessReviewHistoryStatus';
import { AccessReviewHistoryInstance, AccessReviewHistoryScheduleSettings, AccessReviewScope, Entity, UserIdentity } from './index';
import { Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AccessReviewHistoryDefinition extends Entity implements Parsable {
    /** The createdBy property  */
    private _createdBy?;
    /** Timestamp when the access review definition was created.  */
    private _createdDateTime?;
    /** Determines which review decisions will be included in the fetched review history data if specified. Optional on create. All decisions will be included by default if no decisions are provided on create. Possible values are: approve, deny, dontKnow, notReviewed, and notNotified.  */
    private _decisions?;
    /** Name for the access review history data collection. Required.  */
    private _displayName?;
    /** If the accessReviewHistoryDefinition is a recurring definition, instances represent each recurrence. A definition that does not recur will have exactly one instance.  */
    private _instances?;
    /** A timestamp. Reviews ending on or before this date will be included in the fetched history data. Only required if scheduleSettings is not defined.  */
    private _reviewHistoryPeriodEndDateTime?;
    /** A timestamp. Reviews starting on or before this date will be included in the fetched history data. Only required if scheduleSettings is not defined.  */
    private _reviewHistoryPeriodStartDateTime?;
    /** The settings for a recurring access review history definition series. Only required if reviewHistoryPeriodStartDateTime or reviewHistoryPeriodEndDateTime are not defined. Not supported yet.  */
    private _scheduleSettings?;
    /** Used to scope what reviews are included in the fetched history data. Fetches reviews whose scope matches with this provided scope. Required.  */
    private _scopes?;
    /** Represents the status of the review history data collection. The possible values are: done, inProgress, error, requested, unknownFutureValue.  */
    private _status?;
    /**
     * Instantiates a new accessReviewHistoryDefinition and sets the default values.
     */
    constructor();
    /**
     * Gets the createdBy property value. The createdBy property
     * @returns a userIdentity
     */
    get createdBy(): UserIdentity | undefined;
    /**
     * Sets the createdBy property value. The createdBy property
     * @param value Value to set for the createdBy property.
     */
    set createdBy(value: UserIdentity | undefined);
    /**
     * Gets the createdDateTime property value. Timestamp when the access review definition was created.
     * @returns a Date
     */
    get createdDateTime(): Date | undefined;
    /**
     * Sets the createdDateTime property value. Timestamp when the access review definition was created.
     * @param value Value to set for the createdDateTime property.
     */
    set createdDateTime(value: Date | undefined);
    /**
     * Gets the decisions property value. Determines which review decisions will be included in the fetched review history data if specified. Optional on create. All decisions will be included by default if no decisions are provided on create. Possible values are: approve, deny, dontKnow, notReviewed, and notNotified.
     * @returns a accessReviewHistoryDecisionFilter
     */
    get decisions(): AccessReviewHistoryDecisionFilter[] | undefined;
    /**
     * Sets the decisions property value. Determines which review decisions will be included in the fetched review history data if specified. Optional on create. All decisions will be included by default if no decisions are provided on create. Possible values are: approve, deny, dontKnow, notReviewed, and notNotified.
     * @param value Value to set for the decisions property.
     */
    set decisions(value: AccessReviewHistoryDecisionFilter[] | undefined);
    /**
     * Gets the displayName property value. Name for the access review history data collection. Required.
     * @returns a string
     */
    get displayName(): string | undefined;
    /**
     * Sets the displayName property value. Name for the access review history data collection. Required.
     * @param value Value to set for the displayName property.
     */
    set displayName(value: string | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the instances property value. If the accessReviewHistoryDefinition is a recurring definition, instances represent each recurrence. A definition that does not recur will have exactly one instance.
     * @returns a accessReviewHistoryInstance
     */
    get instances(): AccessReviewHistoryInstance[] | undefined;
    /**
     * Sets the instances property value. If the accessReviewHistoryDefinition is a recurring definition, instances represent each recurrence. A definition that does not recur will have exactly one instance.
     * @param value Value to set for the instances property.
     */
    set instances(value: AccessReviewHistoryInstance[] | undefined);
    /**
     * Gets the reviewHistoryPeriodEndDateTime property value. A timestamp. Reviews ending on or before this date will be included in the fetched history data. Only required if scheduleSettings is not defined.
     * @returns a Date
     */
    get reviewHistoryPeriodEndDateTime(): Date | undefined;
    /**
     * Sets the reviewHistoryPeriodEndDateTime property value. A timestamp. Reviews ending on or before this date will be included in the fetched history data. Only required if scheduleSettings is not defined.
     * @param value Value to set for the reviewHistoryPeriodEndDateTime property.
     */
    set reviewHistoryPeriodEndDateTime(value: Date | undefined);
    /**
     * Gets the reviewHistoryPeriodStartDateTime property value. A timestamp. Reviews starting on or before this date will be included in the fetched history data. Only required if scheduleSettings is not defined.
     * @returns a Date
     */
    get reviewHistoryPeriodStartDateTime(): Date | undefined;
    /**
     * Sets the reviewHistoryPeriodStartDateTime property value. A timestamp. Reviews starting on or before this date will be included in the fetched history data. Only required if scheduleSettings is not defined.
     * @param value Value to set for the reviewHistoryPeriodStartDateTime property.
     */
    set reviewHistoryPeriodStartDateTime(value: Date | undefined);
    /**
     * Gets the scheduleSettings property value. The settings for a recurring access review history definition series. Only required if reviewHistoryPeriodStartDateTime or reviewHistoryPeriodEndDateTime are not defined. Not supported yet.
     * @returns a accessReviewHistoryScheduleSettings
     */
    get scheduleSettings(): AccessReviewHistoryScheduleSettings | undefined;
    /**
     * Sets the scheduleSettings property value. The settings for a recurring access review history definition series. Only required if reviewHistoryPeriodStartDateTime or reviewHistoryPeriodEndDateTime are not defined. Not supported yet.
     * @param value Value to set for the scheduleSettings property.
     */
    set scheduleSettings(value: AccessReviewHistoryScheduleSettings | undefined);
    /**
     * Gets the scopes property value. Used to scope what reviews are included in the fetched history data. Fetches reviews whose scope matches with this provided scope. Required.
     * @returns a accessReviewScope
     */
    get scopes(): AccessReviewScope[] | undefined;
    /**
     * Sets the scopes property value. Used to scope what reviews are included in the fetched history data. Fetches reviews whose scope matches with this provided scope. Required.
     * @param value Value to set for the scopes property.
     */
    set scopes(value: AccessReviewScope[] | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the status property value. Represents the status of the review history data collection. The possible values are: done, inProgress, error, requested, unknownFutureValue.
     * @returns a accessReviewHistoryStatus
     */
    get status(): AccessReviewHistoryStatus | undefined;
    /**
     * Sets the status property value. Represents the status of the review history data collection. The possible values are: done, inProgress, error, requested, unknownFutureValue.
     * @param value Value to set for the status property.
     */
    set status(value: AccessReviewHistoryStatus | undefined);
}

import { Entity, UserActivity } from './index';
import { Status } from './status';
import { Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class ActivityHistoryItem extends Entity implements Parsable {
    /** Optional. The duration of active user engagement. if not supplied, this is calculated from the startedDateTime and lastActiveDateTime.  */
    private _activeDurationSeconds?;
    /** The activity property  */
    private _activity?;
    /** Set by the server. DateTime in UTC when the object was created on the server.  */
    private _createdDateTime?;
    /** Optional. UTC DateTime when the historyItem will undergo hard-delete. Can be set by the client.  */
    private _expirationDateTime?;
    /** Optional. UTC DateTime when the historyItem (activity session) was last understood as active or finished - if null, historyItem status should be Ongoing.  */
    private _lastActiveDateTime?;
    /** Set by the server. DateTime in UTC when the object was modified on the server.  */
    private _lastModifiedDateTime?;
    /** Required. UTC DateTime when the historyItem (activity session) was started. Required for timeline history.  */
    private _startedDateTime?;
    /** Set by the server. A status code used to identify valid objects. Values: active, updated, deleted, ignored.  */
    private _status?;
    /** Optional. The timezone in which the user's device used to generate the activity was located at activity creation time. Values supplied as Olson IDs in order to support cross-platform representation.  */
    private _userTimezone?;
    /**
     * Gets the activeDurationSeconds property value. Optional. The duration of active user engagement. if not supplied, this is calculated from the startedDateTime and lastActiveDateTime.
     * @returns a integer
     */
    get activeDurationSeconds(): number | undefined;
    /**
     * Sets the activeDurationSeconds property value. Optional. The duration of active user engagement. if not supplied, this is calculated from the startedDateTime and lastActiveDateTime.
     * @param value Value to set for the activeDurationSeconds property.
     */
    set activeDurationSeconds(value: number | undefined);
    /**
     * Gets the activity property value. The activity property
     * @returns a userActivity
     */
    get activity(): UserActivity | undefined;
    /**
     * Sets the activity property value. The activity property
     * @param value Value to set for the activity property.
     */
    set activity(value: UserActivity | undefined);
    /**
     * Instantiates a new activityHistoryItem and sets the default values.
     */
    constructor();
    /**
     * Gets the createdDateTime property value. Set by the server. DateTime in UTC when the object was created on the server.
     * @returns a Date
     */
    get createdDateTime(): Date | undefined;
    /**
     * Sets the createdDateTime property value. Set by the server. DateTime in UTC when the object was created on the server.
     * @param value Value to set for the createdDateTime property.
     */
    set createdDateTime(value: Date | undefined);
    /**
     * Gets the expirationDateTime property value. Optional. UTC DateTime when the historyItem will undergo hard-delete. Can be set by the client.
     * @returns a Date
     */
    get expirationDateTime(): Date | undefined;
    /**
     * Sets the expirationDateTime property value. Optional. UTC DateTime when the historyItem will undergo hard-delete. Can be set by the client.
     * @param value Value to set for the expirationDateTime property.
     */
    set expirationDateTime(value: Date | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the lastActiveDateTime property value. Optional. UTC DateTime when the historyItem (activity session) was last understood as active or finished - if null, historyItem status should be Ongoing.
     * @returns a Date
     */
    get lastActiveDateTime(): Date | undefined;
    /**
     * Sets the lastActiveDateTime property value. Optional. UTC DateTime when the historyItem (activity session) was last understood as active or finished - if null, historyItem status should be Ongoing.
     * @param value Value to set for the lastActiveDateTime property.
     */
    set lastActiveDateTime(value: Date | undefined);
    /**
     * Gets the lastModifiedDateTime property value. Set by the server. DateTime in UTC when the object was modified on the server.
     * @returns a Date
     */
    get lastModifiedDateTime(): Date | undefined;
    /**
     * Sets the lastModifiedDateTime property value. Set by the server. DateTime in UTC when the object was modified on the server.
     * @param value Value to set for the lastModifiedDateTime property.
     */
    set lastModifiedDateTime(value: Date | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the startedDateTime property value. Required. UTC DateTime when the historyItem (activity session) was started. Required for timeline history.
     * @returns a Date
     */
    get startedDateTime(): Date | undefined;
    /**
     * Sets the startedDateTime property value. Required. UTC DateTime when the historyItem (activity session) was started. Required for timeline history.
     * @param value Value to set for the startedDateTime property.
     */
    set startedDateTime(value: Date | undefined);
    /**
     * Gets the status property value. Set by the server. A status code used to identify valid objects. Values: active, updated, deleted, ignored.
     * @returns a status
     */
    get status(): Status | undefined;
    /**
     * Sets the status property value. Set by the server. A status code used to identify valid objects. Values: active, updated, deleted, ignored.
     * @param value Value to set for the status property.
     */
    set status(value: Status | undefined);
    /**
     * Gets the userTimezone property value. Optional. The timezone in which the user's device used to generate the activity was located at activity creation time. Values supplied as Olson IDs in order to support cross-platform representation.
     * @returns a string
     */
    get userTimezone(): string | undefined;
    /**
     * Sets the userTimezone property value. Optional. The timezone in which the user's device used to generate the activity was located at activity creation time. Values supplied as Olson IDs in order to support cross-platform representation.
     * @param value Value to set for the userTimezone property.
     */
    set userTimezone(value: string | undefined);
}

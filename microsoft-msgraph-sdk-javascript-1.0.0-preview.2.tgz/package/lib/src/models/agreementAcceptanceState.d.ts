/** Provides operations to manage the collection of agreementAcceptance entities.  */
export declare enum AgreementAcceptanceState {
    Accepted = "accepted",
    Declined = "declined",
    UnknownFutureValue = "unknownFutureValue"
}

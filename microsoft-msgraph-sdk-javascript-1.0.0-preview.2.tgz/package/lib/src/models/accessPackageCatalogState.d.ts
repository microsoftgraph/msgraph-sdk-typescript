/** Provides operations to manage the identityGovernance singleton.  */
export declare enum AccessPackageCatalogState {
    Unpublished = "unpublished",
    Published = "published",
    UnknownFutureValue = "unknownFutureValue"
}

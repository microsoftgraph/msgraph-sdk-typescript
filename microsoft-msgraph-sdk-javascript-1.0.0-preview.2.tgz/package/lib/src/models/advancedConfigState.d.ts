/** Provides operations to manage the authenticationMethodsPolicy singleton.  */
export declare enum AdvancedConfigState {
    Default_escaped = "default_escaped",
    Enabled = "enabled",
    Disabled = "disabled",
    UnknownFutureValue = "unknownFutureValue"
}

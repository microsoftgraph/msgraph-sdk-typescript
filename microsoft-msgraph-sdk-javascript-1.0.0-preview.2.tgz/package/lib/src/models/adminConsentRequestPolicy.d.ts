import { AccessReviewReviewerScope, Entity } from './index';
import { Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AdminConsentRequestPolicy extends Entity implements Parsable {
    /** Specifies whether the admin consent request feature is enabled or disabled. Required.  */
    private _isEnabled?;
    /** Specifies whether reviewers will receive notifications. Required.  */
    private _notifyReviewers?;
    /** Specifies whether reviewers will receive reminder emails. Required.  */
    private _remindersEnabled?;
    /** Specifies the duration the request is active before it automatically expires if no decision is applied.  */
    private _requestDurationInDays?;
    /** The list of reviewers for the admin consent. Required.  */
    private _reviewers?;
    /** Specifies the version of this policy. When the policy is updated, this version is updated. Read-only.  */
    private _version?;
    /**
     * Instantiates a new adminConsentRequestPolicy and sets the default values.
     */
    constructor();
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the isEnabled property value. Specifies whether the admin consent request feature is enabled or disabled. Required.
     * @returns a boolean
     */
    get isEnabled(): boolean | undefined;
    /**
     * Sets the isEnabled property value. Specifies whether the admin consent request feature is enabled or disabled. Required.
     * @param value Value to set for the isEnabled property.
     */
    set isEnabled(value: boolean | undefined);
    /**
     * Gets the notifyReviewers property value. Specifies whether reviewers will receive notifications. Required.
     * @returns a boolean
     */
    get notifyReviewers(): boolean | undefined;
    /**
     * Sets the notifyReviewers property value. Specifies whether reviewers will receive notifications. Required.
     * @param value Value to set for the notifyReviewers property.
     */
    set notifyReviewers(value: boolean | undefined);
    /**
     * Gets the remindersEnabled property value. Specifies whether reviewers will receive reminder emails. Required.
     * @returns a boolean
     */
    get remindersEnabled(): boolean | undefined;
    /**
     * Sets the remindersEnabled property value. Specifies whether reviewers will receive reminder emails. Required.
     * @param value Value to set for the remindersEnabled property.
     */
    set remindersEnabled(value: boolean | undefined);
    /**
     * Gets the requestDurationInDays property value. Specifies the duration the request is active before it automatically expires if no decision is applied.
     * @returns a integer
     */
    get requestDurationInDays(): number | undefined;
    /**
     * Sets the requestDurationInDays property value. Specifies the duration the request is active before it automatically expires if no decision is applied.
     * @param value Value to set for the requestDurationInDays property.
     */
    set requestDurationInDays(value: number | undefined);
    /**
     * Gets the reviewers property value. The list of reviewers for the admin consent. Required.
     * @returns a accessReviewReviewerScope
     */
    get reviewers(): AccessReviewReviewerScope[] | undefined;
    /**
     * Sets the reviewers property value. The list of reviewers for the admin consent. Required.
     * @param value Value to set for the reviewers property.
     */
    set reviewers(value: AccessReviewReviewerScope[] | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the version property value. Specifies the version of this policy. When the policy is updated, this version is updated. Read-only.
     * @returns a integer
     */
    get version(): number | undefined;
    /**
     * Sets the version property value. Specifies the version of this policy. When the policy is updated, this version is updated. Read-only.
     * @param value Value to set for the version property.
     */
    set version(value: number | undefined);
}

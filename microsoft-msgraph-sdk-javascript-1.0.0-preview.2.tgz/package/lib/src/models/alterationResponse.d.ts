import { SearchAlteration } from './index';
import { SearchAlterationType } from './searchAlterationType';
import { AdditionalDataHolder, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AlterationResponse implements AdditionalDataHolder, Parsable {
    /** Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.  */
    private _additionalData;
    /** Defines the original user query string.  */
    private _originalQueryString?;
    /** Defines the details of the alteration information for the spelling correction.  */
    private _queryAlteration?;
    /** Defines the type of the spelling correction. Possible values are: suggestion, modification.  */
    private _queryAlterationType?;
    /**
     * Gets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @returns a Record<string, unknown>
     */
    get additionalData(): Record<string, unknown>;
    /**
     * Sets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @param value Value to set for the AdditionalData property.
     */
    set additionalData(value: Record<string, unknown>);
    /**
     * Instantiates a new alterationResponse and sets the default values.
     */
    constructor();
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the originalQueryString property value. Defines the original user query string.
     * @returns a string
     */
    get originalQueryString(): string | undefined;
    /**
     * Sets the originalQueryString property value. Defines the original user query string.
     * @param value Value to set for the originalQueryString property.
     */
    set originalQueryString(value: string | undefined);
    /**
     * Gets the queryAlteration property value. Defines the details of the alteration information for the spelling correction.
     * @returns a searchAlteration
     */
    get queryAlteration(): SearchAlteration | undefined;
    /**
     * Sets the queryAlteration property value. Defines the details of the alteration information for the spelling correction.
     * @param value Value to set for the queryAlteration property.
     */
    set queryAlteration(value: SearchAlteration | undefined);
    /**
     * Gets the queryAlterationType property value. Defines the type of the spelling correction. Possible values are: suggestion, modification.
     * @returns a searchAlterationType
     */
    get queryAlterationType(): SearchAlterationType | undefined;
    /**
     * Sets the queryAlterationType property value. Defines the type of the spelling correction. Possible values are: suggestion, modification.
     * @param value Value to set for the queryAlterationType property.
     */
    set queryAlterationType(value: SearchAlterationType | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
}

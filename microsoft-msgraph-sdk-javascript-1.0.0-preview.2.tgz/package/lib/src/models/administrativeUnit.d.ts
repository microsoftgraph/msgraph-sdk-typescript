import { DirectoryObject, Extension, ScopedRoleMembership } from './index';
import { Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AdministrativeUnit extends DirectoryObject implements Parsable {
    /** An optional description for the administrative unit. Supports $filter (eq, ne, in, startsWith), $search.  */
    private _description?;
    /** Display name for the administrative unit. Supports $filter (eq, ne, not, ge, le, in, startsWith, and eq on null values), $search, and $orderBy.  */
    private _displayName?;
    /** The collection of open extensions defined for this administrative unit. Nullable.  */
    private _extensions?;
    /** Users and groups that are members of this administrative unit. Supports $expand.  */
    private _members?;
    /** Scoped-role members of this administrative unit.  */
    private _scopedRoleMembers?;
    /** Controls whether the administrative unit and its members are hidden or public. Can be set to HiddenMembership. If not set (value is null), the default behavior is public. When set to HiddenMembership, only members of the administrative unit can list other members of the administrative unit.  */
    private _visibility?;
    /**
     * Instantiates a new administrativeUnit and sets the default values.
     */
    constructor();
    /**
     * Gets the description property value. An optional description for the administrative unit. Supports $filter (eq, ne, in, startsWith), $search.
     * @returns a string
     */
    get description(): string | undefined;
    /**
     * Sets the description property value. An optional description for the administrative unit. Supports $filter (eq, ne, in, startsWith), $search.
     * @param value Value to set for the description property.
     */
    set description(value: string | undefined);
    /**
     * Gets the displayName property value. Display name for the administrative unit. Supports $filter (eq, ne, not, ge, le, in, startsWith, and eq on null values), $search, and $orderBy.
     * @returns a string
     */
    get displayName(): string | undefined;
    /**
     * Sets the displayName property value. Display name for the administrative unit. Supports $filter (eq, ne, not, ge, le, in, startsWith, and eq on null values), $search, and $orderBy.
     * @param value Value to set for the displayName property.
     */
    set displayName(value: string | undefined);
    /**
     * Gets the extensions property value. The collection of open extensions defined for this administrative unit. Nullable.
     * @returns a extension
     */
    get extensions(): Extension[] | undefined;
    /**
     * Sets the extensions property value. The collection of open extensions defined for this administrative unit. Nullable.
     * @param value Value to set for the extensions property.
     */
    set extensions(value: Extension[] | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the members property value. Users and groups that are members of this administrative unit. Supports $expand.
     * @returns a directoryObject
     */
    get members(): DirectoryObject[] | undefined;
    /**
     * Sets the members property value. Users and groups that are members of this administrative unit. Supports $expand.
     * @param value Value to set for the members property.
     */
    set members(value: DirectoryObject[] | undefined);
    /**
     * Gets the scopedRoleMembers property value. Scoped-role members of this administrative unit.
     * @returns a scopedRoleMembership
     */
    get scopedRoleMembers(): ScopedRoleMembership[] | undefined;
    /**
     * Sets the scopedRoleMembers property value. Scoped-role members of this administrative unit.
     * @param value Value to set for the scopedRoleMembers property.
     */
    set scopedRoleMembers(value: ScopedRoleMembership[] | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the visibility property value. Controls whether the administrative unit and its members are hidden or public. Can be set to HiddenMembership. If not set (value is null), the default behavior is public. When set to HiddenMembership, only members of the administrative unit can list other members of the administrative unit.
     * @returns a string
     */
    get visibility(): string | undefined;
    /**
     * Sets the visibility property value. Controls whether the administrative unit and its members are hidden or public. Can be set to HiddenMembership. If not set (value is null), the default behavior is public. When set to HiddenMembership, only members of the administrative unit can list other members of the administrative unit.
     * @param value Value to set for the visibility property.
     */
    set visibility(value: string | undefined);
}

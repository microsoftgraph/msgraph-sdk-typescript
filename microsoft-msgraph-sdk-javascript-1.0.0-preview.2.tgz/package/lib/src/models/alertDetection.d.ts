import { AdditionalDataHolder, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AlertDetection implements AdditionalDataHolder, Parsable {
    /** Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.  */
    private _additionalData;
    /** The detectionType property  */
    private _detectionType?;
    /** The method property  */
    private _method?;
    /** The name property  */
    private _name?;
    /**
     * Gets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @returns a Record<string, unknown>
     */
    get additionalData(): Record<string, unknown>;
    /**
     * Sets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @param value Value to set for the AdditionalData property.
     */
    set additionalData(value: Record<string, unknown>);
    /**
     * Instantiates a new alertDetection and sets the default values.
     */
    constructor();
    /**
     * Gets the detectionType property value. The detectionType property
     * @returns a string
     */
    get detectionType(): string | undefined;
    /**
     * Sets the detectionType property value. The detectionType property
     * @param value Value to set for the detectionType property.
     */
    set detectionType(value: string | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the method property value. The method property
     * @returns a string
     */
    get method(): string | undefined;
    /**
     * Sets the method property value. The method property
     * @param value Value to set for the method property.
     */
    set method(value: string | undefined);
    /**
     * Gets the name property value. The name property
     * @returns a string
     */
    get name(): string | undefined;
    /**
     * Sets the name property value. The name property
     * @param value Value to set for the name property.
     */
    set name(value: string | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
}

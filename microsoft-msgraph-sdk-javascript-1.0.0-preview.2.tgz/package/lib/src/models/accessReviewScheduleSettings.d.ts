import { AccessReviewApplyAction, PatternedRecurrence } from './index';
import { AdditionalDataHolder, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AccessReviewScheduleSettings implements AdditionalDataHolder, Parsable {
    /** Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.  */
    private _additionalData;
    /** Optional field. Describes the  actions to take once a review is complete. There are two types that are currently supported: removeAccessApplyAction (default) and disableAndDeleteUserApplyAction. Field only needs to be specified in the case of disableAndDeleteUserApplyAction.  */
    private _applyActions?;
    /** Indicates whether decisions are automatically applied. When set to false, an admin must apply the decisions manually once the reviewer completes the access review. When set to true, decisions are applied automatically after the access review instance duration ends, whether or not the reviewers have responded. Default value is false.  */
    private _autoApplyDecisionsEnabled?;
    /** Decision chosen if defaultDecisionEnabled is true. Can be one of Approve, Deny, or Recommendation.  */
    private _defaultDecision?;
    /** Indicates whether the default decision is enabled or disabled when reviewers do not respond. Default value is false.  */
    private _defaultDecisionEnabled?;
    /** Duration of each recurrence of review (accessReviewInstance) in number of days.  */
    private _instanceDurationInDays?;
    /** Indicates whether reviewers are required to provide justification with their decision. Default value is false.  */
    private _justificationRequiredOnApproval?;
    /** Indicates whether emails are enabled or disabled. Default value is false.  */
    private _mailNotificationsEnabled?;
    /** Indicates whether decision recommendations are enabled or disabled.  */
    private _recommendationsEnabled?;
    /** Detailed settings for recurrence using the standard Outlook recurrence object.  Note: Only dayOfMonth, interval, and type (weekly, absoluteMonthly) properties are supported. Use the property startDate on recurrenceRange to determine the day the review starts.  */
    private _recurrence?;
    /** Indicates whether reminders are enabled or disabled. Default value is false.  */
    private _reminderNotificationsEnabled?;
    /**
     * Gets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @returns a Record<string, unknown>
     */
    get additionalData(): Record<string, unknown>;
    /**
     * Sets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @param value Value to set for the AdditionalData property.
     */
    set additionalData(value: Record<string, unknown>);
    /**
     * Gets the applyActions property value. Optional field. Describes the  actions to take once a review is complete. There are two types that are currently supported: removeAccessApplyAction (default) and disableAndDeleteUserApplyAction. Field only needs to be specified in the case of disableAndDeleteUserApplyAction.
     * @returns a accessReviewApplyAction
     */
    get applyActions(): AccessReviewApplyAction[] | undefined;
    /**
     * Sets the applyActions property value. Optional field. Describes the  actions to take once a review is complete. There are two types that are currently supported: removeAccessApplyAction (default) and disableAndDeleteUserApplyAction. Field only needs to be specified in the case of disableAndDeleteUserApplyAction.
     * @param value Value to set for the applyActions property.
     */
    set applyActions(value: AccessReviewApplyAction[] | undefined);
    /**
     * Gets the autoApplyDecisionsEnabled property value. Indicates whether decisions are automatically applied. When set to false, an admin must apply the decisions manually once the reviewer completes the access review. When set to true, decisions are applied automatically after the access review instance duration ends, whether or not the reviewers have responded. Default value is false.
     * @returns a boolean
     */
    get autoApplyDecisionsEnabled(): boolean | undefined;
    /**
     * Sets the autoApplyDecisionsEnabled property value. Indicates whether decisions are automatically applied. When set to false, an admin must apply the decisions manually once the reviewer completes the access review. When set to true, decisions are applied automatically after the access review instance duration ends, whether or not the reviewers have responded. Default value is false.
     * @param value Value to set for the autoApplyDecisionsEnabled property.
     */
    set autoApplyDecisionsEnabled(value: boolean | undefined);
    /**
     * Instantiates a new accessReviewScheduleSettings and sets the default values.
     */
    constructor();
    /**
     * Gets the defaultDecision property value. Decision chosen if defaultDecisionEnabled is true. Can be one of Approve, Deny, or Recommendation.
     * @returns a string
     */
    get defaultDecision(): string | undefined;
    /**
     * Sets the defaultDecision property value. Decision chosen if defaultDecisionEnabled is true. Can be one of Approve, Deny, or Recommendation.
     * @param value Value to set for the defaultDecision property.
     */
    set defaultDecision(value: string | undefined);
    /**
     * Gets the defaultDecisionEnabled property value. Indicates whether the default decision is enabled or disabled when reviewers do not respond. Default value is false.
     * @returns a boolean
     */
    get defaultDecisionEnabled(): boolean | undefined;
    /**
     * Sets the defaultDecisionEnabled property value. Indicates whether the default decision is enabled or disabled when reviewers do not respond. Default value is false.
     * @param value Value to set for the defaultDecisionEnabled property.
     */
    set defaultDecisionEnabled(value: boolean | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the instanceDurationInDays property value. Duration of each recurrence of review (accessReviewInstance) in number of days.
     * @returns a integer
     */
    get instanceDurationInDays(): number | undefined;
    /**
     * Sets the instanceDurationInDays property value. Duration of each recurrence of review (accessReviewInstance) in number of days.
     * @param value Value to set for the instanceDurationInDays property.
     */
    set instanceDurationInDays(value: number | undefined);
    /**
     * Gets the justificationRequiredOnApproval property value. Indicates whether reviewers are required to provide justification with their decision. Default value is false.
     * @returns a boolean
     */
    get justificationRequiredOnApproval(): boolean | undefined;
    /**
     * Sets the justificationRequiredOnApproval property value. Indicates whether reviewers are required to provide justification with their decision. Default value is false.
     * @param value Value to set for the justificationRequiredOnApproval property.
     */
    set justificationRequiredOnApproval(value: boolean | undefined);
    /**
     * Gets the mailNotificationsEnabled property value. Indicates whether emails are enabled or disabled. Default value is false.
     * @returns a boolean
     */
    get mailNotificationsEnabled(): boolean | undefined;
    /**
     * Sets the mailNotificationsEnabled property value. Indicates whether emails are enabled or disabled. Default value is false.
     * @param value Value to set for the mailNotificationsEnabled property.
     */
    set mailNotificationsEnabled(value: boolean | undefined);
    /**
     * Gets the recommendationsEnabled property value. Indicates whether decision recommendations are enabled or disabled.
     * @returns a boolean
     */
    get recommendationsEnabled(): boolean | undefined;
    /**
     * Sets the recommendationsEnabled property value. Indicates whether decision recommendations are enabled or disabled.
     * @param value Value to set for the recommendationsEnabled property.
     */
    set recommendationsEnabled(value: boolean | undefined);
    /**
     * Gets the recurrence property value. Detailed settings for recurrence using the standard Outlook recurrence object.  Note: Only dayOfMonth, interval, and type (weekly, absoluteMonthly) properties are supported. Use the property startDate on recurrenceRange to determine the day the review starts.
     * @returns a patternedRecurrence
     */
    get recurrence(): PatternedRecurrence | undefined;
    /**
     * Sets the recurrence property value. Detailed settings for recurrence using the standard Outlook recurrence object.  Note: Only dayOfMonth, interval, and type (weekly, absoluteMonthly) properties are supported. Use the property startDate on recurrenceRange to determine the day the review starts.
     * @param value Value to set for the recurrence property.
     */
    set recurrence(value: PatternedRecurrence | undefined);
    /**
     * Gets the reminderNotificationsEnabled property value. Indicates whether reminders are enabled or disabled. Default value is false.
     * @returns a boolean
     */
    get reminderNotificationsEnabled(): boolean | undefined;
    /**
     * Sets the reminderNotificationsEnabled property value. Indicates whether reminders are enabled or disabled. Default value is false.
     * @param value Value to set for the reminderNotificationsEnabled property.
     */
    set reminderNotificationsEnabled(value: boolean | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
}

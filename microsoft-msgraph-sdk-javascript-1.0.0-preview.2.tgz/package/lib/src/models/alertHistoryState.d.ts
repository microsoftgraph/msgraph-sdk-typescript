import { AlertFeedback } from './alertFeedback';
import { AlertStatus } from './alertStatus';
import { AdditionalDataHolder, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AlertHistoryState implements AdditionalDataHolder, Parsable {
    /** Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.  */
    private _additionalData;
    /** The Application ID of the calling application that submitted an update (PATCH) to the alert. The appId should be extracted from the auth token and not entered manually by the calling application.  */
    private _appId?;
    /** UPN of user the alert was assigned to (note: alert.assignedTo only stores the last value/UPN).  */
    private _assignedTo?;
    /** Comment entered by signed-in user.  */
    private _comments?;
    /** Analyst feedback on the alert in this update. Possible values are: unknown, truePositive, falsePositive, benignPositive.  */
    private _feedback?;
    /** Alert status value (if updated). Possible values are: unknown, newAlert, inProgress, resolved, dismissed.  */
    private _status?;
    /** Date and time of the alert update. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z  */
    private _updatedDateTime?;
    /** UPN of the signed-in user that updated the alert (taken from the bearer token - if in user/delegated auth mode).  */
    private _user?;
    /**
     * Gets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @returns a Record<string, unknown>
     */
    get additionalData(): Record<string, unknown>;
    /**
     * Sets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @param value Value to set for the AdditionalData property.
     */
    set additionalData(value: Record<string, unknown>);
    /**
     * Gets the appId property value. The Application ID of the calling application that submitted an update (PATCH) to the alert. The appId should be extracted from the auth token and not entered manually by the calling application.
     * @returns a string
     */
    get appId(): string | undefined;
    /**
     * Sets the appId property value. The Application ID of the calling application that submitted an update (PATCH) to the alert. The appId should be extracted from the auth token and not entered manually by the calling application.
     * @param value Value to set for the appId property.
     */
    set appId(value: string | undefined);
    /**
     * Gets the assignedTo property value. UPN of user the alert was assigned to (note: alert.assignedTo only stores the last value/UPN).
     * @returns a string
     */
    get assignedTo(): string | undefined;
    /**
     * Sets the assignedTo property value. UPN of user the alert was assigned to (note: alert.assignedTo only stores the last value/UPN).
     * @param value Value to set for the assignedTo property.
     */
    set assignedTo(value: string | undefined);
    /**
     * Gets the comments property value. Comment entered by signed-in user.
     * @returns a string
     */
    get comments(): string[] | undefined;
    /**
     * Sets the comments property value. Comment entered by signed-in user.
     * @param value Value to set for the comments property.
     */
    set comments(value: string[] | undefined);
    /**
     * Instantiates a new alertHistoryState and sets the default values.
     */
    constructor();
    /**
     * Gets the feedback property value. Analyst feedback on the alert in this update. Possible values are: unknown, truePositive, falsePositive, benignPositive.
     * @returns a alertFeedback
     */
    get feedback(): AlertFeedback | undefined;
    /**
     * Sets the feedback property value. Analyst feedback on the alert in this update. Possible values are: unknown, truePositive, falsePositive, benignPositive.
     * @param value Value to set for the feedback property.
     */
    set feedback(value: AlertFeedback | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the status property value. Alert status value (if updated). Possible values are: unknown, newAlert, inProgress, resolved, dismissed.
     * @returns a alertStatus
     */
    get status(): AlertStatus | undefined;
    /**
     * Sets the status property value. Alert status value (if updated). Possible values are: unknown, newAlert, inProgress, resolved, dismissed.
     * @param value Value to set for the status property.
     */
    set status(value: AlertStatus | undefined);
    /**
     * Gets the updatedDateTime property value. Date and time of the alert update. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z
     * @returns a Date
     */
    get updatedDateTime(): Date | undefined;
    /**
     * Sets the updatedDateTime property value. Date and time of the alert update. The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 is 2014-01-01T00:00:00Z
     * @param value Value to set for the updatedDateTime property.
     */
    set updatedDateTime(value: Date | undefined);
    /**
     * Gets the user property value. UPN of the signed-in user that updated the alert (taken from the bearer token - if in user/delegated auth mode).
     * @returns a string
     */
    get user(): string | undefined;
    /**
     * Sets the user property value. UPN of the signed-in user that updated the alert (taken from the bearer token - if in user/delegated auth mode).
     * @param value Value to set for the user property.
     */
    set user(value: string | undefined);
}

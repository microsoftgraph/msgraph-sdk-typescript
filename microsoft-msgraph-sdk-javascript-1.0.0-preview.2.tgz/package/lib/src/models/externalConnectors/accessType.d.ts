/** Provides operations to manage the collection of externalConnection entities.  */
export declare enum AccessType {
    Grant = "grant",
    Deny = "deny",
    UnknownFutureValue = "unknownFutureValue"
}

/** Provides operations to manage the collection of externalConnection entities.  */
export declare enum AclType {
    User = "user",
    Group = "group",
    Everyone = "everyone",
    EveryoneExceptGuests = "everyoneExceptGuests",
    ExternalGroup = "externalGroup",
    UnknownFutureValue = "unknownFutureValue"
}

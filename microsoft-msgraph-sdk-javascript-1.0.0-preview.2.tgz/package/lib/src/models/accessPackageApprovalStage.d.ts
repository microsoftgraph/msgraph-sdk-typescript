import { SubjectSet } from './index';
import { AdditionalDataHolder, Duration, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AccessPackageApprovalStage implements AdditionalDataHolder, Parsable {
    /** Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.  */
    private _additionalData;
    /** The number of days that a request can be pending a response before it is automatically denied.  */
    private _durationBeforeAutomaticDenial?;
    /** If escalation is required, the time a request can be pending a response from a primary approver.  */
    private _durationBeforeEscalation?;
    /** If escalation is enabled and the primary approvers do not respond before the escalation time, the escalationApprovers are the users who will be asked to approve requests.  */
    private _escalationApprovers?;
    /** The subjects, typically users, who are the fallback escalation approvers.  */
    private _fallbackEscalationApprovers?;
    /** The subjects, typically users, who are the fallback primary approvers.  */
    private _fallbackPrimaryApprovers?;
    /** Indicates whether the approver is required to provide a justification for approving a request.  */
    private _isApproverJustificationRequired?;
    /** If true, then one or more escalationApprovers are configured in this approval stage.  */
    private _isEscalationEnabled?;
    /** The subjects, typically users, who will be asked to approve requests. A collection of singleUser, groupMembers, requestorManager, internalSponsors or externalSponsors.  */
    private _primaryApprovers?;
    /**
     * Gets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @returns a Record<string, unknown>
     */
    get additionalData(): Record<string, unknown>;
    /**
     * Sets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @param value Value to set for the AdditionalData property.
     */
    set additionalData(value: Record<string, unknown>);
    /**
     * Instantiates a new accessPackageApprovalStage and sets the default values.
     */
    constructor();
    /**
     * Gets the durationBeforeAutomaticDenial property value. The number of days that a request can be pending a response before it is automatically denied.
     * @returns a Duration
     */
    get durationBeforeAutomaticDenial(): Duration | undefined;
    /**
     * Sets the durationBeforeAutomaticDenial property value. The number of days that a request can be pending a response before it is automatically denied.
     * @param value Value to set for the durationBeforeAutomaticDenial property.
     */
    set durationBeforeAutomaticDenial(value: Duration | undefined);
    /**
     * Gets the durationBeforeEscalation property value. If escalation is required, the time a request can be pending a response from a primary approver.
     * @returns a Duration
     */
    get durationBeforeEscalation(): Duration | undefined;
    /**
     * Sets the durationBeforeEscalation property value. If escalation is required, the time a request can be pending a response from a primary approver.
     * @param value Value to set for the durationBeforeEscalation property.
     */
    set durationBeforeEscalation(value: Duration | undefined);
    /**
     * Gets the escalationApprovers property value. If escalation is enabled and the primary approvers do not respond before the escalation time, the escalationApprovers are the users who will be asked to approve requests.
     * @returns a subjectSet
     */
    get escalationApprovers(): SubjectSet[] | undefined;
    /**
     * Sets the escalationApprovers property value. If escalation is enabled and the primary approvers do not respond before the escalation time, the escalationApprovers are the users who will be asked to approve requests.
     * @param value Value to set for the escalationApprovers property.
     */
    set escalationApprovers(value: SubjectSet[] | undefined);
    /**
     * Gets the fallbackEscalationApprovers property value. The subjects, typically users, who are the fallback escalation approvers.
     * @returns a subjectSet
     */
    get fallbackEscalationApprovers(): SubjectSet[] | undefined;
    /**
     * Sets the fallbackEscalationApprovers property value. The subjects, typically users, who are the fallback escalation approvers.
     * @param value Value to set for the fallbackEscalationApprovers property.
     */
    set fallbackEscalationApprovers(value: SubjectSet[] | undefined);
    /**
     * Gets the fallbackPrimaryApprovers property value. The subjects, typically users, who are the fallback primary approvers.
     * @returns a subjectSet
     */
    get fallbackPrimaryApprovers(): SubjectSet[] | undefined;
    /**
     * Sets the fallbackPrimaryApprovers property value. The subjects, typically users, who are the fallback primary approvers.
     * @param value Value to set for the fallbackPrimaryApprovers property.
     */
    set fallbackPrimaryApprovers(value: SubjectSet[] | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the isApproverJustificationRequired property value. Indicates whether the approver is required to provide a justification for approving a request.
     * @returns a boolean
     */
    get isApproverJustificationRequired(): boolean | undefined;
    /**
     * Sets the isApproverJustificationRequired property value. Indicates whether the approver is required to provide a justification for approving a request.
     * @param value Value to set for the isApproverJustificationRequired property.
     */
    set isApproverJustificationRequired(value: boolean | undefined);
    /**
     * Gets the isEscalationEnabled property value. If true, then one or more escalationApprovers are configured in this approval stage.
     * @returns a boolean
     */
    get isEscalationEnabled(): boolean | undefined;
    /**
     * Sets the isEscalationEnabled property value. If true, then one or more escalationApprovers are configured in this approval stage.
     * @param value Value to set for the isEscalationEnabled property.
     */
    set isEscalationEnabled(value: boolean | undefined);
    /**
     * Gets the primaryApprovers property value. The subjects, typically users, who will be asked to approve requests. A collection of singleUser, groupMembers, requestorManager, internalSponsors or externalSponsors.
     * @returns a subjectSet
     */
    get primaryApprovers(): SubjectSet[] | undefined;
    /**
     * Sets the primaryApprovers property value. The subjects, typically users, who will be asked to approve requests. A collection of singleUser, groupMembers, requestorManager, internalSponsors or externalSponsors.
     * @param value Value to set for the primaryApprovers property.
     */
    set primaryApprovers(value: SubjectSet[] | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
}

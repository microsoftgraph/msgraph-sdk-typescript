/** Provides operations to manage the drive singleton.  */
export declare enum ActionState {
    None = "none",
    Pending = "pending",
    Canceled = "canceled",
    Active = "active",
    Done = "done",
    Failed = "failed",
    NotSupported = "notSupported"
}

import { AccessReviewHistoryDefinition, AccessReviewScheduleDefinition, Entity } from './index';
import { Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AccessReviewSet extends Entity implements Parsable {
    /** Represents the template and scheduling for an access review.  */
    private _definitions?;
    /** Represents a collection of access review history data and the scopes used to collect that data.  */
    private _historyDefinitions?;
    /**
     * Instantiates a new accessReviewSet and sets the default values.
     */
    constructor();
    /**
     * Gets the definitions property value. Represents the template and scheduling for an access review.
     * @returns a accessReviewScheduleDefinition
     */
    get definitions(): AccessReviewScheduleDefinition[] | undefined;
    /**
     * Sets the definitions property value. Represents the template and scheduling for an access review.
     * @param value Value to set for the definitions property.
     */
    set definitions(value: AccessReviewScheduleDefinition[] | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the historyDefinitions property value. Represents a collection of access review history data and the scopes used to collect that data.
     * @returns a accessReviewHistoryDefinition
     */
    get historyDefinitions(): AccessReviewHistoryDefinition[] | undefined;
    /**
     * Sets the historyDefinitions property value. Represents a collection of access review history data and the scopes used to collect that data.
     * @param value Value to set for the historyDefinitions property.
     */
    set historyDefinitions(value: AccessReviewHistoryDefinition[] | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
}

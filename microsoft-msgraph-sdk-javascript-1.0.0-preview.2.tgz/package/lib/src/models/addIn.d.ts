import { KeyValue } from './index';
import { AdditionalDataHolder, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AddIn implements AdditionalDataHolder, Parsable {
    /** Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.  */
    private _additionalData;
    /** The id property  */
    private _id?;
    /** The properties property  */
    private _properties?;
    /** The type property  */
    private _type?;
    /**
     * Gets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @returns a Record<string, unknown>
     */
    get additionalData(): Record<string, unknown>;
    /**
     * Sets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @param value Value to set for the AdditionalData property.
     */
    set additionalData(value: Record<string, unknown>);
    /**
     * Instantiates a new addIn and sets the default values.
     */
    constructor();
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the id property value. The id property
     * @returns a string
     */
    get id(): string | undefined;
    /**
     * Sets the id property value. The id property
     * @param value Value to set for the id property.
     */
    set id(value: string | undefined);
    /**
     * Gets the properties property value. The properties property
     * @returns a keyValue
     */
    get properties(): KeyValue[] | undefined;
    /**
     * Sets the properties property value. The properties property
     * @param value Value to set for the properties property.
     */
    set properties(value: KeyValue[] | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the type property value. The type property
     * @returns a string
     */
    get type(): string | undefined;
    /**
     * Sets the type property value. The type property
     * @param value Value to set for the type property.
     */
    set type(value: string | undefined);
}

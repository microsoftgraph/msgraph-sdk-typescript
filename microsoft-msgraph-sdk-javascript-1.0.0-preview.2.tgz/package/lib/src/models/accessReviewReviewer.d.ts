import { Entity } from './index';
import { Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AccessReviewReviewer extends Entity implements Parsable {
    /** The date when the reviewer was added for the access review.  */
    private _createdDateTime?;
    /** Name of reviewer.  */
    private _displayName?;
    /** User principal name of the reviewer.  */
    private _userPrincipalName?;
    /**
     * Instantiates a new accessReviewReviewer and sets the default values.
     */
    constructor();
    /**
     * Gets the createdDateTime property value. The date when the reviewer was added for the access review.
     * @returns a Date
     */
    get createdDateTime(): Date | undefined;
    /**
     * Sets the createdDateTime property value. The date when the reviewer was added for the access review.
     * @param value Value to set for the createdDateTime property.
     */
    set createdDateTime(value: Date | undefined);
    /**
     * Gets the displayName property value. Name of reviewer.
     * @returns a string
     */
    get displayName(): string | undefined;
    /**
     * Sets the displayName property value. Name of reviewer.
     * @param value Value to set for the displayName property.
     */
    set displayName(value: string | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the userPrincipalName property value. User principal name of the reviewer.
     * @returns a string
     */
    get userPrincipalName(): string | undefined;
    /**
     * Sets the userPrincipalName property value. User principal name of the reviewer.
     * @param value Value to set for the userPrincipalName property.
     */
    set userPrincipalName(value: string | undefined);
}

import { AdditionalDataHolder, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
export declare class AccessReviewInstanceDecisionItemResource implements AdditionalDataHolder, Parsable {
    /** Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.  */
    private _additionalData;
    /** Display name of the resource  */
    private _displayName?;
    /** Identifier of the resource  */
    private _id?;
    /** Type of resource. Types include: Group, ServicePrincipal, DirectoryRole, AzureRole, AccessPackageAssignmentPolicy.  */
    private _type?;
    /**
     * Gets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @returns a Record<string, unknown>
     */
    get additionalData(): Record<string, unknown>;
    /**
     * Sets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @param value Value to set for the AdditionalData property.
     */
    set additionalData(value: Record<string, unknown>);
    /**
     * Instantiates a new accessReviewInstanceDecisionItemResource and sets the default values.
     */
    constructor();
    /**
     * Gets the displayName property value. Display name of the resource
     * @returns a string
     */
    get displayName(): string | undefined;
    /**
     * Sets the displayName property value. Display name of the resource
     * @param value Value to set for the displayName property.
     */
    set displayName(value: string | undefined);
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the id property value. Identifier of the resource
     * @returns a string
     */
    get id(): string | undefined;
    /**
     * Sets the id property value. Identifier of the resource
     * @param value Value to set for the id property.
     */
    set id(value: string | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
    /**
     * Gets the type property value. Type of resource. Types include: Group, ServicePrincipal, DirectoryRole, AzureRole, AccessPackageAssignmentPolicy.
     * @returns a string
     */
    get type(): string | undefined;
    /**
     * Sets the type property value. Type of resource. Types include: Group, ServicePrincipal, DirectoryRole, AzureRole, AccessPackageAssignmentPolicy.
     * @param value Value to set for the type property.
     */
    set type(value: string | undefined);
}

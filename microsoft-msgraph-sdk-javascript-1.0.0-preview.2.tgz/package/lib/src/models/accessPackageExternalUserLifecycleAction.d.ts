/** Provides operations to manage the identityGovernance singleton.  */
export declare enum AccessPackageExternalUserLifecycleAction {
    None = "none",
    BlockSignIn = "blockSignIn",
    BlockSignInAndDelete = "blockSignInAndDelete",
    UnknownFutureValue = "unknownFutureValue"
}

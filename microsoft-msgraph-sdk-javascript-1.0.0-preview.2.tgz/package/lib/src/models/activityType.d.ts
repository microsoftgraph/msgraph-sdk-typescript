/** Provides operations to manage the identityProtectionRoot singleton.  */
export declare enum ActivityType {
    Signin = "signin",
    User = "user",
    UnknownFutureValue = "unknownFutureValue"
}

/** Conceptual container for user and group directory objects.  */
export declare class AdministrativeUnitsRequestBuilderGetQueryParameters {
    /** Include count of items  */
    count?: boolean | undefined;
    /** Expand related entities  */
    expand?: string[] | undefined;
    /** Filter items by property values  */
    filter?: string | undefined;
    /** Order items by property values  */
    orderby?: string[] | undefined;
    /** Search items by search phrases  */
    search?: string | undefined;
    /** Select properties to be returned  */
    select?: string[] | undefined;
    /** Skip the first n items  */
    skip?: number | undefined;
    /** Show only the first n items  */
    top?: number | undefined;
    /**
     * Maps the query parameters names to their encoded names for the URI template parsing.
     * @param originalName The original query parameter name in the class.
     * @returns a string
     */
    getQueryParameter(originalName: string | undefined): string;
}

import { AdministrativeUnit } from '../../../models/';
import { AdministrativeUnitItemRequestBuilderGetQueryParameters } from './administrativeUnitItemRequestBuilderGetQueryParameters';
import { ExtensionsRequestBuilder } from './extensions/extensionsRequestBuilder';
import { ExtensionItemRequestBuilder } from './extensions/item/extensionItemRequestBuilder';
import { DirectoryObjectItemRequestBuilder } from './members/item/directoryObjectItemRequestBuilder';
import { MembersRequestBuilder } from './members/membersRequestBuilder';
import { ScopedRoleMembershipItemRequestBuilder } from './scopedRoleMembers/item/scopedRoleMembershipItemRequestBuilder';
import { ScopedRoleMembersRequestBuilder } from './scopedRoleMembers/scopedRoleMembersRequestBuilder';
import { RequestAdapter, RequestInformation, RequestOption, ResponseHandler } from '@microsoft/kiota-abstractions';
/** Provides operations to manage the administrativeUnits property of the microsoft.graph.directory entity.  */
export declare class AdministrativeUnitItemRequestBuilder {
    /** The extensions property  */
    get extensions(): ExtensionsRequestBuilder;
    /** The members property  */
    get members(): MembersRequestBuilder;
    /** Path parameters for the request  */
    private readonly pathParameters;
    /** The request adapter to use to execute the requests.  */
    private readonly requestAdapter;
    /** The scopedRoleMembers property  */
    get scopedRoleMembers(): ScopedRoleMembersRequestBuilder;
    /** Url template to use to build the URL for the current request builder  */
    private readonly urlTemplate;
    /**
     * Instantiates a new AdministrativeUnitItemRequestBuilder and sets the default values.
     * @param pathParameters The raw url or the Url template parameters for the request.
     * @param requestAdapter The request adapter to use to execute the requests.
     */
    constructor(pathParameters: Record<string, unknown> | string | undefined, requestAdapter: RequestAdapter);
    /**
     * Delete navigation property administrativeUnits for directory
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createDeleteRequestInformation(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Conceptual container for user and group directory objects.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @returns a RequestInformation
     */
    createGetRequestInformation(queryParameters?: AdministrativeUnitItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Update the navigation property administrativeUnits in directory
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createPatchRequestInformation(body: AdministrativeUnit | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Delete navigation property administrativeUnits for directory
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    delete(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
    /**
     * Gets an item from the github.com/microsoftgraph/msgraph-sdk-typescript/.directory.administrativeUnits.item.extensions.item collection
     * @param id Unique identifier of the item
     * @returns a extensionItemRequestBuilder
     */
    extensionsById(id: string): ExtensionItemRequestBuilder;
    /**
     * Conceptual container for user and group directory objects.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     * @returns a Promise of AdministrativeUnit
     */
    get(queryParameters?: AdministrativeUnitItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<AdministrativeUnit | undefined>;
    /**
     * Gets an item from the github.com/microsoftgraph/msgraph-sdk-typescript/.directory.administrativeUnits.item.members.item collection
     * @param id Unique identifier of the item
     * @returns a directoryObjectItemRequestBuilder
     */
    membersById(id: string): DirectoryObjectItemRequestBuilder;
    /**
     * Update the navigation property administrativeUnits in directory
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    patch(body: AdministrativeUnit | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
    /**
     * Gets an item from the github.com/microsoftgraph/msgraph-sdk-typescript/.directory.administrativeUnits.item.scopedRoleMembers.item collection
     * @param id Unique identifier of the item
     * @returns a scopedRoleMembershipItemRequestBuilder
     */
    scopedRoleMembersById(id: string): ScopedRoleMembershipItemRequestBuilder;
}

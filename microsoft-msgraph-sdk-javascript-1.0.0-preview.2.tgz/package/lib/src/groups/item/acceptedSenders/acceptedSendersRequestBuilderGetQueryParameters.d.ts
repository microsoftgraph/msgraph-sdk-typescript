/** The list of users or groups that are allowed to create post's or calendar events in this group. If this list is non-empty then only users or groups listed here are allowed to post.  */
export declare class AcceptedSendersRequestBuilderGetQueryParameters {
    /** Include count of items  */
    count?: boolean | undefined;
    /** Filter items by property values  */
    filter?: string | undefined;
    /** Order items by property values  */
    orderby?: string[] | undefined;
    /** Select properties to be returned  */
    select?: string[] | undefined;
    /** Skip the first n items  */
    skip?: number | undefined;
    /** Show only the first n items  */
    top?: number | undefined;
    /**
     * Maps the query parameters names to their encoded names for the URI template parsing.
     * @param originalName The original query parameter name in the class.
     * @returns a string
     */
    getQueryParameter(originalName: string | undefined): string;
}

import { DirectoryObjectCollectionResponse } from '../../../models/';
import { AcceptedSendersRequestBuilderGetQueryParameters } from './acceptedSendersRequestBuilderGetQueryParameters';
import { CountRequestBuilder } from './count/countRequestBuilder';
import { RequestAdapter, RequestInformation, RequestOption, ResponseHandler } from '@microsoft/kiota-abstractions';
/** Provides operations to manage the acceptedSenders property of the microsoft.graph.group entity.  */
export declare class AcceptedSendersRequestBuilder {
    /** The count property  */
    get count(): CountRequestBuilder;
    /** Path parameters for the request  */
    private readonly pathParameters;
    /** The request adapter to use to execute the requests.  */
    private readonly requestAdapter;
    /** Url template to use to build the URL for the current request builder  */
    private readonly urlTemplate;
    /**
     * Instantiates a new AcceptedSendersRequestBuilder and sets the default values.
     * @param pathParameters The raw url or the Url template parameters for the request.
     * @param requestAdapter The request adapter to use to execute the requests.
     */
    constructor(pathParameters: Record<string, unknown> | string | undefined, requestAdapter: RequestAdapter);
    /**
     * The list of users or groups that are allowed to create post's or calendar events in this group. If this list is non-empty then only users or groups listed here are allowed to post.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @returns a RequestInformation
     */
    createGetRequestInformation(queryParameters?: AcceptedSendersRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * The list of users or groups that are allowed to create post's or calendar events in this group. If this list is non-empty then only users or groups listed here are allowed to post.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     * @returns a Promise of DirectoryObjectCollectionResponse
     */
    get(queryParameters?: AcceptedSendersRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<DirectoryObjectCollectionResponse | undefined>;
}

import { AdditionalDataHolder, Parsable, ParseNode, SerializationWriter } from '@microsoft/kiota-abstractions';
/** Provides operations to call the accept method.  */
export declare class AcceptRequestBody implements AdditionalDataHolder, Parsable {
    /** Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.  */
    private _additionalData;
    /** The Comment property  */
    private _comment?;
    /** The SendResponse property  */
    private _sendResponse?;
    /**
     * Gets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @returns a Record<string, unknown>
     */
    get additionalData(): Record<string, unknown>;
    /**
     * Sets the additionalData property value. Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
     * @param value Value to set for the AdditionalData property.
     */
    set additionalData(value: Record<string, unknown>);
    /**
     * Gets the comment property value. The Comment property
     * @returns a string
     */
    get comment(): string | undefined;
    /**
     * Sets the comment property value. The Comment property
     * @param value Value to set for the Comment property.
     */
    set comment(value: string | undefined);
    /**
     * Instantiates a new acceptRequestBody and sets the default values.
     */
    constructor();
    /**
     * The deserialization information for the current model
     * @returns a Record<string, (node: ParseNode) => void>
     */
    getFieldDeserializers(): Record<string, (node: ParseNode) => void>;
    /**
     * Gets the sendResponse property value. The SendResponse property
     * @returns a boolean
     */
    get sendResponse(): boolean | undefined;
    /**
     * Sets the sendResponse property value. The SendResponse property
     * @param value Value to set for the SendResponse property.
     */
    set sendResponse(value: boolean | undefined);
    /**
     * Serializes information the current object
     * @param writer Serialization writer to use to serialize this model
     */
    serialize(writer: SerializationWriter): void;
}

import { TermsAndConditionsAcceptanceStatus, TermsAndConditionsAcceptanceStatusCollectionResponse } from '../../../../models/';
import { AcceptanceStatusesRequestBuilderGetQueryParameters } from './acceptanceStatusesRequestBuilderGetQueryParameters';
import { CountRequestBuilder } from './count/countRequestBuilder';
import { RequestAdapter, RequestInformation, RequestOption, ResponseHandler } from '@microsoft/kiota-abstractions';
/** Provides operations to manage the acceptanceStatuses property of the microsoft.graph.termsAndConditions entity.  */
export declare class AcceptanceStatusesRequestBuilder {
    /** The count property  */
    get count(): CountRequestBuilder;
    /** Path parameters for the request  */
    private readonly pathParameters;
    /** The request adapter to use to execute the requests.  */
    private readonly requestAdapter;
    /** Url template to use to build the URL for the current request builder  */
    private readonly urlTemplate;
    /**
     * Instantiates a new AcceptanceStatusesRequestBuilder and sets the default values.
     * @param pathParameters The raw url or the Url template parameters for the request.
     * @param requestAdapter The request adapter to use to execute the requests.
     */
    constructor(pathParameters: Record<string, unknown> | string | undefined, requestAdapter: RequestAdapter);
    /**
     * The list of acceptance statuses for this T&C policy.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @returns a RequestInformation
     */
    createGetRequestInformation(queryParameters?: AcceptanceStatusesRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Create new navigation property to acceptanceStatuses for deviceManagement
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createPostRequestInformation(body: TermsAndConditionsAcceptanceStatus | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * The list of acceptance statuses for this T&C policy.
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     * @returns a Promise of TermsAndConditionsAcceptanceStatusCollectionResponse
     */
    get(queryParameters?: AcceptanceStatusesRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<TermsAndConditionsAcceptanceStatusCollectionResponse | undefined>;
    /**
     * Create new navigation property to acceptanceStatuses for deviceManagement
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     * @returns a Promise of TermsAndConditionsAcceptanceStatus
     */
    post(body: TermsAndConditionsAcceptanceStatus | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<TermsAndConditionsAcceptanceStatus | undefined>;
}

/** The localized version of the terms of use agreement files attached to the agreement.  */
export declare class AgreementFileLocalizationItemRequestBuilderGetQueryParameters {
    /** Expand related entities  */
    expand?: string[] | undefined;
    /** Select properties to be returned  */
    select?: string[] | undefined;
    /**
     * Maps the query parameters names to their encoded names for the URI template parsing.
     * @param originalName The original query parameter name in the class.
     * @returns a string
     */
    getQueryParameter(originalName: string | undefined): string;
}

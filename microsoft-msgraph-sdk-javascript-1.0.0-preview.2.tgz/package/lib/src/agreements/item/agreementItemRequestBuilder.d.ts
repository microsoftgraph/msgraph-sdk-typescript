import { Agreement } from '../../models/';
import { AcceptancesRequestBuilder } from './acceptances/acceptancesRequestBuilder';
import { AgreementAcceptanceItemRequestBuilder } from './acceptances/item/agreementAcceptanceItemRequestBuilder';
import { AgreementItemRequestBuilderGetQueryParameters } from './agreementItemRequestBuilderGetQueryParameters';
import { FileRequestBuilder } from './file/fileRequestBuilder';
import { FilesRequestBuilder } from './files/filesRequestBuilder';
import { AgreementFileLocalizationItemRequestBuilder } from './files/item/agreementFileLocalizationItemRequestBuilder';
import { RequestAdapter, RequestInformation, RequestOption, ResponseHandler } from '@microsoft/kiota-abstractions';
/** Provides operations to manage the collection of agreement entities.  */
export declare class AgreementItemRequestBuilder {
    /** The acceptances property  */
    get acceptances(): AcceptancesRequestBuilder;
    /** The file property  */
    get file(): FileRequestBuilder;
    /** The files property  */
    get files(): FilesRequestBuilder;
    /** Path parameters for the request  */
    private readonly pathParameters;
    /** The request adapter to use to execute the requests.  */
    private readonly requestAdapter;
    /** Url template to use to build the URL for the current request builder  */
    private readonly urlTemplate;
    /**
     * Gets an item from the github.com/microsoftgraph/msgraph-sdk-typescript/.agreements.item.acceptances.item collection
     * @param id Unique identifier of the item
     * @returns a agreementAcceptanceItemRequestBuilder
     */
    acceptancesById(id: string): AgreementAcceptanceItemRequestBuilder;
    /**
     * Instantiates a new AgreementItemRequestBuilder and sets the default values.
     * @param pathParameters The raw url or the Url template parameters for the request.
     * @param requestAdapter The request adapter to use to execute the requests.
     */
    constructor(pathParameters: Record<string, unknown> | string | undefined, requestAdapter: RequestAdapter);
    /**
     * Delete entity from agreements
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createDeleteRequestInformation(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Get entity from agreements by key
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @returns a RequestInformation
     */
    createGetRequestInformation(queryParameters?: AgreementItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Update entity in agreements
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @returns a RequestInformation
     */
    createPatchRequestInformation(body: Agreement | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined): RequestInformation;
    /**
     * Delete entity from agreements
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    delete(headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
    /**
     * Gets an item from the github.com/microsoftgraph/msgraph-sdk-typescript/.agreements.item.files.item collection
     * @param id Unique identifier of the item
     * @returns a agreementFileLocalizationItemRequestBuilder
     */
    filesById(id: string): AgreementFileLocalizationItemRequestBuilder;
    /**
     * Get entity from agreements by key
     * @param headers Request headers
     * @param options Request options
     * @param queryParameters Request query parameters
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     * @returns a Promise of Agreement
     */
    get(queryParameters?: AgreementItemRequestBuilderGetQueryParameters | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<Agreement | undefined>;
    /**
     * Update entity in agreements
     * @param body
     * @param headers Request headers
     * @param options Request options
     * @param responseHandler Response handler to use in place of the default response handling provided by the core service
     */
    patch(body: Agreement | undefined, headers?: Record<string, string> | undefined, options?: RequestOption[] | undefined, responseHandler?: ResponseHandler | undefined): Promise<void>;
}

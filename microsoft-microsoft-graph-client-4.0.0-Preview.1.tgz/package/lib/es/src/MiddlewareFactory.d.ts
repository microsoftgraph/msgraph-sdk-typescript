/**
 * -------------------------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation.  All Rights Reserved.  Licensed under the MIT License.
 * See License in the project root for license information.
 * -------------------------------------------------------------------------------------------
 */
import { Middleware } from "@microsoft/kiota-http-fetchlibrary";
import { ClientOptions } from "./IClientOptions";
import { GraphSDKConfig } from "./requestBuilderUtils/GraphSDKConfig";
export declare function getDefaultMiddlewareChain(clientOptions: ClientOptions, allowedHosts: Set<string>, graphSDKConfig?: GraphSDKConfig): Middleware[];

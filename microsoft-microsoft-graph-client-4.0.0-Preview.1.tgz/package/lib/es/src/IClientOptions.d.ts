/**
 * -------------------------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation.  All Rights Reserved.  Licensed under the MIT License.
 * See License in the project root for license information.
 * -------------------------------------------------------------------------------------------
 */
import { BaseBearerTokenAuthenticationProvider } from "@microsoft/kiota-abstractions";
import { Middleware } from "@microsoft/kiota-http-fetchlibrary";
import { FetchOptions } from "./IFetchOptions";
/**
 * @interface
 * Options for initializing the Graph Client
 * @property {Function} [authProvider] - The authentication provider instance
 * @property {string} [baseUrl] - Base url that needs to be appended to every request
 * @property {boolean} [debugLogging] - The boolean to enable/disable debug logging
 * @property {string} [defaultVersion] - The default version that needs to be used while making graph api request
 * @property {FetchOptions} [fetchOptions] - The options for fetch request
 * @property {Middleware| Middleware[]} [middleware] - The first middleware of the middleware chain or an array of the Middleware handlers
 * @property {Set<string>}[customHosts] - A set of custom host names. Should contain hostnames only.
 */
export interface ClientOptions {
    authProvider: BaseBearerTokenAuthenticationProvider;
    baseUrl?: string;
    debugLogging?: boolean;
    defaultVersion?: string;
    fetchOptions?: FetchOptions;
    middleware?: Middleware | Middleware[];
    customFetch?: (input: string, init?: RequestInit) => Promise<Response>;
}

/**
 * -------------------------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation.  All Rights Reserved.  Licensed under the MIT License.
 * See License in the project root for license information.
 * -------------------------------------------------------------------------------------------
 */
/**
 * @module SimpleAccessTokenProvider
 */
import { AccessTokenProvider, AllowedHostsValidator } from "@microsoft/kiota-abstractions";
/**
 * @class
 * Simple Access Token Provider that returns an access token.
 * @extends AuthenticationProvider
 */
export declare class SimpleAccessTokenProvider implements AccessTokenProvider {
    private getAccessTokenCallback;
    private scopes;
    private allowedhosts?;
    /**
     * @public
     * @constructor
     * Creates an instance of SimpleAccessTokenProvider
     * @param {()=>Promise<string>}getAccessTokenCallback  - The callback function to get the access token
     * @param {string[]} scopes - The scopes for the access token
     * @param {allowedHosts} allowedhosts -  A set of custom host names. Should contain hostnames only.
     * @returns An instance of SimpleAccessTokenProvider
     */
    constructor(getAccessTokenCallback: (scopes?: string[]) => Promise<string>, scopes?: string[] | undefined, allowedhosts?: Set<string>);
    private readonly allowedHostsValidator;
    getAllowedHostsValidator: () => AllowedHostsValidator;
    /**
     * @public
     * @async
     * To get the access token
     * @returns The promise that resolves to an access token
     */
    getAuthorizationToken(url: string): Promise<string>;
}

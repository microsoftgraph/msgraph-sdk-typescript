/**
 * -------------------------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation.  All Rights Reserved.  Licensed under the MIT License.
 * See License in the project root for license information.
 * -------------------------------------------------------------------------------------------
 */
/**
 * @module Client
 */
import { BaseBearerTokenAuthenticationProvider } from "@microsoft/kiota-abstractions";
import { HttpClient } from "@microsoft/kiota-http-fetchlibrary";
import { GraphBaseClient } from ".";
import { GraphRequest } from "./GraphRequest";
import { ClientOptions } from "./IClientOptions";
export declare class Client implements GraphBaseClient {
    /**
     * @private
     * A member which stores the Client instance options
     */
    private config;
    /**
     * @private
     * A member which holds the HTTPClient instance
     */
    protected httpClient: HttpClient;
    protected authProvider: BaseBearerTokenAuthenticationProvider;
    /**
     * @public
     * @static
     * To create a client instance with options and initializes the default middleware chain
     * @param {Options} options - The options for client instance
     * @returns The Client instance
     */
    static init(options: ClientOptions): Client;
    /**
     * @private
     * @constructor
     * Creates an instance of Client
     * @param {ClientOptions} clientOptions - The options to instantiate the client object
     */
    private constructor();
    /**
     * @public
     * Entry point to make requests
     * @param {string} path - The path string value
     * @returns The graph request instance
     */
    api(path: string): GraphRequest;
}

/**
 * -------------------------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation.  All Rights Reserved.  Licensed under the MIT License.
 * See License in the project root for license information.
 * -------------------------------------------------------------------------------------------
 */
/**
 * @module AuthenticationHandler
 */
import { BaseBearerTokenAuthenticationProvider, RequestOption } from "@microsoft/kiota-abstractions";
import { Middleware } from "@microsoft/kiota-http-fetchlibrary";
/**
 * @class
 * @implements Middleware
 * Class representing AuthenticationHandler
 */
export declare class AuthenticationHandler implements Middleware {
    private authenticationProvider;
    /**
     * @private
     * A member representing the authorization header name
     */
    private static AUTHORIZATION_HEADER;
    /**
     * @private
     * A member to hold next middleware in the middleware chain
     */
    next: Middleware;
    /**
     * @public
     * @constructor
     * Creates an instance of AuthenticationHandler
     * @param {AuthenticationProvider} authenticationProvider - The authentication provider for the authentication handler
     */
    constructor(authenticationProvider: BaseBearerTokenAuthenticationProvider);
    /**
     * @public
     * @async
     * To execute the current middleware
     * @param {Context} context - The context object of the request
     * @returns A Promise that resolves to nothing
     */
    execute(url: string, requestInit: RequestInit, requestOptions?: Record<string, RequestOption>): Promise<Response>;
}

/**
 * -------------------------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation.  All Rights Reserved.  Licensed under the MIT License.
 * See License in the project root for license information.
 * -------------------------------------------------------------------------------------------
 */
import { RequestOption } from "@microsoft/kiota-abstractions";
import { TelemetryHandlerOptions } from "@microsoft/kiota-http-fetchlibrary";
import { GraphTelemetryConfig } from "./GraphTelemetryConfig";
/**
 * @private
 * @static
 * A member holding the language prefix for the sdk version header value
 */
export declare const CORE_PRODUCT_NAME = "graph-js-core";
export declare const coreSdkVersionValue: string;
export declare const graphTelemetryCallback: (url: string, requestInit: RequestInit, requestOptions?: Record<string, RequestOption>, telemetryInfomation?: unknown) => void;
export declare const getGraphTelemetryCallback: (graphTelemetry: GraphTelemetryConfig) => TelemetryHandlerOptions;
